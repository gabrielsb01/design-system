module.exports = {
  extends: ["@wooden-script/eslint-config/node", "./base.js"],
};
