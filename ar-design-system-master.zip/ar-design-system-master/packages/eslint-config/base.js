module.exports = {
  ignorePatterns: ["dist"]
};
