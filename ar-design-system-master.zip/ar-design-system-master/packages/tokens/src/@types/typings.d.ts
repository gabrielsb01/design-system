export type TTokens = {
  [token in number | string]: boolean | number | string
}
