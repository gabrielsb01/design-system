import type { TTokens } from './typings'

export type TColorShades = Record<string, string>

export type TColors = TTokens

export interface IColorsDataScale {
  title: string
  path: string
  indexes?: string[]
  names?: string[]
}

export interface IColorsDataDescription {
  title: string
  description: string
  scales: IColorsDataScale[]
}

export interface IColorsDataConfig {
  scaleIndexes: Array<string | number>
}

export interface IColorsData {
  config: IColorsDataConfig
  descriptions: Record<string, IColorsDataDescription>
}
