import _ from 'lodash'
import { ResolvableTo, KeyValuePair } from 'tailwindcss/types/config'

const totalLayers = 10
const gap = 1

export const zIndex: ResolvableTo<KeyValuePair> = _.fromPairs(
  _.range(0, totalLayers * gap, gap).map((i) => [`${i}`, `${i}`]),
)
