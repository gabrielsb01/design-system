import { IColorsData } from '../@types/colors'

const colors: IColorsData = {
  config: {
    scaleIndexes: [
      '900',
      '800',
      '700',
      '600',
      '500',
      '400',
      '300',
      '200',
      '100',
      '50',
    ],
  },
  descriptions: {
    brand: {
      title: 'Brand',
      description:
        'Utilizar para indicar ação em elementos interativos, ou para dar destaque a elementos não interativos.',
      scales: [
        {
          title: 'Branding Theme',
          path: '.',
          indexes: ['brand.primary', 'brand.secondary'],
          names: ['Brand / Primary', 'Brand / Secondary'],
        },
        { title: 'Primary scale', path: 'brand.primary' },
        { title: 'Secondary scale', path: 'brand.secondary' },
      ],
    },
    neutral: {
      title: 'Neutral',
      description:
        'Utilizar em elementos não interativos, como fundos e textos.',
      scales: [
        { title: 'Background scale', path: 'neutral.background' },
        { title: 'Grey scale', path: 'neutral.gray' },
      ],
    },
    support: {
      title: 'Support',
      description:
        'Utilizar em feedbacks de mudança de estado, como sucesso ou falha.',
      scales: [
        { title: 'Informative', path: 'support.informative' },
        { title: 'Positive', path: 'support.positive' },
        { title: 'Warning', path: 'support.warning' },
        { title: 'Negative', path: 'support.negative' },
      ],
    },
  },
}

export const descriptions = Object.freeze({
  colors,
})
