export const borderStyles = {
  none: 'none',
  hidden: 'hidden',
  solid: 'solid',
  dashed: 'dashed',
  dotted: 'dotted',
  double: 'double',
}
