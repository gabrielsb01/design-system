export const borderWidths = {
  'border-0': '0px',
  border: '1px',
  'border-2': '2px',
  'border-4': '4px',
  'border-8': '8px',
}
