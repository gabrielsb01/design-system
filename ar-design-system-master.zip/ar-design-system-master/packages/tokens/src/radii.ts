export const radii = {
  'rounded-none': '0px',
  rounded: '2px',
  'rounded-xs': '4px',
  'rounded-sm': '8px',
  'rounded-md': '12px',
  'rounded-lg': '16px',
  'rounded-xl': '20px',
  'rounded-2xl': '24px',
  'rounded-3xl': '28px',
  'rounded-full': '9999px',
  'rounded-circle': '50%',
}
