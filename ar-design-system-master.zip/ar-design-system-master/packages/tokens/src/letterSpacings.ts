export const letterSpacings = {
  xs: '-0.5px',
  sm: '-0.25px',
  md: '0px',
  lg: '0.25px',
  xl: '0.5px',
}
