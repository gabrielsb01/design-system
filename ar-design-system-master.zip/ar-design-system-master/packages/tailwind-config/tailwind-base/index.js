/** @type {import('tailwindcss').Config} */

const {
  animation,
  colors,
  keyframes,
  zIndex,
} = require("@gogipsy/ds-tokens")

module.exports = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    colors,
    extend: {
      zIndex,
      keyframes,
      animation,
    },
  },
  plugins: [],
}
