import { addons } from '@storybook/manager-api'
import '../src/styles/storybook.css'

addons.setConfig({
  sidebar:{
    showRoots: false,
  },
})
