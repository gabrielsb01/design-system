type TColors = {
  [key: string]: T | RecursiveObject<T>;
};

export interface IStoreCartState {
  colors: TColors
}

export interface IStoreCartActions {
  setColors: (colors: false | TColors) => void
  updateColors: (color: Partial<TColors>) => void
}

export interface IColorsStore {
  data: IStoreCartState
  actions: IStoreCartActions
}
