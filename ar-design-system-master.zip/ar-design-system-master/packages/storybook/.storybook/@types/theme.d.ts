import type { ThemeVarsPartial } from '@storybook/theming'

export interface IThemeProps extends ThemeVarsPartial{}
