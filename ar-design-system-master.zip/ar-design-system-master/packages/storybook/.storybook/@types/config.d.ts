export type TViewportType = 'desktop' | 'mobile' | 'tablet' | 'other';

export interface IViewportStyles {
  height: string;
  width: string;
}

export interface IViewport {
  name: string;
  styles: IViewportStyles;
  type: TViewportType
}
