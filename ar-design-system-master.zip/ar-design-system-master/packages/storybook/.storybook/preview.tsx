import type { Preview } from '@storybook/react'

import { INITIAL_VIEWPORTS } from '@storybook/addon-viewport'

import '../src/styles/preview.css'

import Theme from './config/theme'
import customViewports from './config/viewport'
import { ThemedDocsContainer } from '../src/utils/storybook/ThemedDocsContainer';

const parameters: Preview = {
  parameters: {
    tags:['autodocs'],
    actions: { argTypesRegex: '^on[A-Z].*' },
    options: {
      // order: ['Widgets', ['Payments', ['Documentation', '*']]],
      enableShortcuts: true,
      sidebarAnimations: true,
      isFullscreen: false,
      isToolshown: true,
      panelPosition: 'bottom',
      showNav: true,
      showPanel: true,
    },
    a11y:{
        element: '#root',
        config: {},
        options: {},
        manual: false,
    },
    controls: {
      expanded: true,
    },
    viewport: {
      viewports: {
        ...INITIAL_VIEWPORTS,
        ...customViewports
      },
    },
    darkMode: {
      dark: Theme.dark,
      light: Theme.light,
      stylePreview: true,
    },
    docs: {
      container: ThemedDocsContainer,
    },
  },

}

export default parameters
