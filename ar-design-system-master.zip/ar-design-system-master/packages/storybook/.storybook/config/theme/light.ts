
import { create } from '@storybook/theming/create'
import { darken, lighten } from "polished"

import type { IThemeProps } from "../../../@types/theme"
import type { ThemeVarsColors } from '@storybook/theming'

import { colors, themeValues } from "./base"
import _ from "lodash"

const tokens:Partial<ThemeVarsColors> = {
  colorPrimary: colors.secondary,
  colorSecondary: colors.primary,
  textColor: colors.text,
  appBg: darken(0.05, colors.background),
  barBg: darken(0.05, colors.background),
  appContentBg: darken(0.005, colors.background),
  appBorderColor: darken(0.4, colors.background),
  inputBg: 'transparent',
  inputBorder: lighten(0.2, colors.text),
  inputTextColor: darken(0.5, colors.text),
  appPreviewBg: lighten(1, colors.background),
  inputBorderRadius: 4,
  appBorderRadius:0,

  textMutedColor:lighten(0.2, colors.text),
  barHoverColor: lighten(0, colors.text),
  barSelectedColor:colors.primary,
  barTextColor:lighten(0.15, colors.text),

  buttonBg:  darken(0.1, colors.background),
  buttonBorder: darken(0.3, colors.background),
  booleanBg: darken(0.1, colors.background),
  booleanSelectedBg: lighten(0.6, colors.text),

}

const themeProps: IThemeProps  = {
  ...themeValues,
  ...tokens,
  base: 'light',
  brandImage: '/img/logo/logomarca-dark.svg',
}

const theme = create(themeProps)

export default Object.freeze({
  theme
})
