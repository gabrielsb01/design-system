import { IThemeProps } from "../../../@types/theme"

export const colors = {
  primary: '#173F8F',
  secondary: '#FFB300',
  text: "#5A5A5A",
  background: '#F4F4F4'
}

export const themeValues:Partial<IThemeProps> = {
  brandTitle: 'Gipsyy',
  brandUrl: 'https://example.com',
  brandTarget: '_self',
}
