import { create } from '@storybook/theming/create'

import { darken, lighten } from "polished"

import type { IThemeProps } from "../../../@types/theme"

import { colors, themeValues } from "./base"
import _ from 'lodash'
import { ThemeVarsColors } from '@storybook/theming'

const tokens:Partial<ThemeVarsColors> = {
  colorPrimary: colors.primary,
  colorSecondary: colors.secondary,
  textColor: lighten(.8, colors.text),
  appBg: darken(0.7, colors.background),
  barBg: darken(0.7, colors.background),
  appContentBg: darken(0.6, colors.background),
  appBorderColor: darken(0.5, colors.background),
  inputBg: 'transparent',
  inputBorder: lighten(0.3, colors.text),
  inputTextColor: lighten(0.6, colors.text),
  textMutedColor:lighten(0.3, colors.text),
  appPreviewBg: darken(0.8, colors.background),
  barHoverColor: lighten(0.6, colors.text),
  barSelectedColor:colors.secondary,
  inputBorderRadius: 6,
  appBorderRadius:0,
  barTextColor:lighten(0.3, colors.text),
  buttonBg: darken(0.7, colors.background),
  buttonBorder: lighten(0.3, colors.text),
  booleanBg: lighten(0.05, colors.text),
  booleanSelectedBg: darken(0.7, colors.background),

}

const themeProps: IThemeProps = {
  ...themeValues,
  ...tokens,
  base: 'dark',
  brandImage: '/img/logo/logomarca-light.svg',
}

const theme = create(themeProps)

export default Object.freeze({
  theme,
})
