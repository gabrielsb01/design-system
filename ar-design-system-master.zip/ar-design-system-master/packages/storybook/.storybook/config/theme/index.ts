import { rgba } from 'polished';
import dark from './dark'
import light from './light'



const body = document.body;
const inlineStyle = document.createElement('style');
inlineStyle.innerHTML = `:root{

  --sb-color-dark-colorPrimary:${dark.theme.colorPrimary};
  --sb-color-dark-colorSecondary:${dark.theme.colorSecondary};
  --sb-color-dark-textColor:${dark.theme.textColor};
  --sb-color-dark-appBg:${dark.theme.appBg};
  --sb-color-dark-barBg:${dark.theme.barBg};
  --sb-color-dark-appContentBg:${dark.theme.appContentBg};
  --sb-color-dark-appBorderColor:${dark.theme.appBorderColor};
  --sb-color-dark-inputBg:${dark.theme.inputBg};
  --sb-color-dark-inputBorder:${dark.theme.inputBorder};
  --sb-color-dark-inputTextColor:${dark.theme.inputTextColor};
  --sb-color-dark-textMutedColor:${dark.theme.textMutedColor};
  --sb-color-dark-appPreviewBg:${dark.theme.appPreviewBg};
  --sb-color-dark-barHoverColor:${dark.theme.barHoverColor};
  --sb-color-dark-barSelectedColor:${dark.theme.barSelectedColor};
  --sb-color-dark-inputBorderRadius:${dark.theme.inputBorderRadius};
  --sb-color-dark-appBorderRadius:${dark.theme.appBorderRadius};
  --sb-color-dark-barTextColor:${dark.theme.barTextColor};
  --sb-color-dark-buttonBg:${dark.theme.buttonBg};
  --sb-color-dark-buttonBorder:${dark.theme.buttonBorder};
  --sb-color-dark-booleanBg:${dark.theme.booleanBg};
  --sb-color-dark-booleanSelectedBg:${dark.theme.booleanSelectedBg};

   --sb-color-dark-colorSecondary-glass:${rgba(dark.theme.colorSecondary,.1)};
   --sb-color-dark-colorPrimary-glass:${rgba(dark.theme.colorPrimary,.1)};

  --sb-color-light-colorPrimary:${light.theme.colorPrimary};
  --sb-color-light-colorSecondary:${light.theme.colorSecondary};
  --sb-color-light-textColor:${light.theme.textColor};
  --sb-color-light-appBg:${light.theme.appBg};
  --sb-color-light-barBg:${light.theme.barBg};
  --sb-color-light-appContentBg:${light.theme.appContentBg};
  --sb-color-light-appBorderColor:${light.theme.appBorderColor};
  --sb-color-light-inputBg:${light.theme.inputBg};
  --sb-color-light-inputBorder:${light.theme.inputBorder};
  --sb-color-light-inputTextColor:${light.theme.inputTextColor};
  --sb-color-light-textMutedColor:${light.theme.textMutedColor};
  --sb-color-light-appPreviewBg:${light.theme.appPreviewBg};
  --sb-color-light-barHoverColor:${light.theme.barHoverColor};
  --sb-color-light-barSelectedColor:${light.theme.barSelectedColor};
  --sb-color-light-inputBorderRadius:${light.theme.inputBorderRadius};
  --sb-color-light-appBorderRadius:${light.theme.appBorderRadius};
  --sb-color-light-barTextColor:${light.theme.barTextColor};
  --sb-color-light-buttonBg:${light.theme.buttonBg};
  --sb-color-light-buttonBorder:${light.theme.buttonBorder};
  --sb-color-light-booleanBg:${light.theme.booleanBg};
  --sb-color-light-booleanSelectedBg:${light.theme.booleanSelectedBg};
  }`;

body.appendChild(inlineStyle);

export default Object.freeze({
  dark: dark.theme,
  light: light.theme,
})
