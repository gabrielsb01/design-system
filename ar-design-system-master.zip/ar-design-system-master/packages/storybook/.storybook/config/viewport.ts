import { IViewport } from "../@types/config"

const desktop:IViewport = {
  name: 'Desktop',
  type: 'desktop',
  styles: {
    width: '1280px',
    height: '800px',
  },
}

const tablet:IViewport = {
  name: 'Tablet',
  type: 'tablet',
  styles: {
    width: '768px',
    height: '1024px',
  },
}

const mobile:IViewport = {
  name: 'Mobile',
  type: 'mobile',
  styles: {
    width: '360px',
    height: '640px',
  },
}

export default Object.freeze({
  desktop,
  tablet,
  mobile,
})
