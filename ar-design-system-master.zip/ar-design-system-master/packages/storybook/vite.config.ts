/// <reference types="vite/client" >
import react from '@vitejs/plugin-react'
import path from 'path'
import { defineConfig } from 'vite'

export default defineConfig({
  resolve: {
    alias: {
      _UTL: path.resolve(__dirname, './src/services/util'),
      _STR: path.resolve(__dirname, './src/services/store'),
      _SRV: path.resolve(__dirname, './src/services'),
      shadcn: path.resolve(__dirname, './src/components'),
      '@': path.resolve(__dirname, './src/@types'),
      '#': path.resolve(__dirname, './src/docs'),
      '~': path.resolve(__dirname, './src'),
    },
  },
  plugins: [react()],
})
