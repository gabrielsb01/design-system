import type { ISwitchProps } from '@gogipsy/design-system'

import { Switch } from '@gogipsy/design-system'
import { Bus, Check, RoadHorizon, X } from '@phosphor-icons/react'
import { Meta, StoryObj } from '@storybook/react'
import { fn } from '@storybook/test'

import { TestSwitch } from '~/_tests/components/TestSwitch'

const Test = new TestSwitch({ defaultStatus: false })

const storyMeta: Meta<ISwitchProps> = {
  title: 'Form/Switch',
  component: Switch,
  tags: ['autodocs'],
  args: {
    name: 'Switch',
    variant: 'primary',
    defaultChecked: false,
    disabled: false,
    onChange: fn(),
  },
  argTypes: {
    onChange: {
      action: 'Change Value',
      table: {
        disable: true,
      },
    },
    variant: {
      table: {
        disable: true,
      },
    },

    icon: {
      table: {
        disable: true,
      },
    },
    offIcon: {
      table: {
        disable: true,
      },
    },
  },
  parameters: {
    design: [
      {
        name: 'Anatomy',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2265-684&mode=design&t=x6tKFfKtke6ye9tM-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
      {
        name: 'Measurements',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2388-842&mode=design&t=9pcxKp4ZbLw5hwhU-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
    ],
  },
}

export default storyMeta

export const Primary: StoryObj<ISwitchProps> = {
  args: {
    variant: 'primary',
  },
}
export const Secondary: StoryObj<ISwitchProps> = {
  args: {
    variant: 'secondary',
  },
}
export const Informative: StoryObj<ISwitchProps> = {
  args: {
    variant: 'informative',
    value: ['Guanabara', 'Gipsyy'],
  },
}
export const Positive: StoryObj<ISwitchProps> = {
  args: {
    variant: 'positive',
  },
}
export const Warning: StoryObj<ISwitchProps> = {
  args: {
    variant: 'warning',
  },
}
export const Negative: StoryObj<ISwitchProps> = {
  args: {
    variant: 'negative',
  },
}

export const With_icon: StoryObj<ISwitchProps> = {
  args: {
    variant: 'positive',
    icon: <RoadHorizon weight="bold" />,
  },
}

export const With_off_icon: StoryObj<ISwitchProps> = {
  args: {
    variant: 'primary',
    icon: <Check weight="bold" />,
    offIcon: <X weight="bold" size={10} />,
  },
}

export const Without_off_icon: StoryObj<ISwitchProps> = {
  args: {
    variant: 'informative',
    icon: <Bus />,
    offIcon: null,
  },
}

export const State_variation: StoryObj<ISwitchProps> = {
  args: {
    icon: <RoadHorizon weight="bold" />,
    onVariant: 'positive',
    offVariant: 'negative',
  },
}

export const With_tests: StoryObj<ISwitchProps> = {
  args: {},
  play: Test.testId('SwitchInput').run,
}
