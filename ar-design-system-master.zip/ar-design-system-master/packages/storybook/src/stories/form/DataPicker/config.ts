import type { TTextStoryProps } from '@gogipsy/design-system'
import type { ArgTypes, Parameters } from '@storybook/types'

import { iconsLucide } from '@gogipsy/design-system'

export const sourceExample = {
  fixedLabel: `
import React, { useState } from "react";
import { TextField } from "@gogipsy/design-system";

export const FixedLabel = () => {
  const [supporting, setSupporting] = useState(null)

  const name = "textfield-name"
  const icon = { name: "Bus", position: "start" }
  const fixedLabel = "Fixed Label Text"

  return (
    <TextField.Root name={name} icon={icon}>
      <TextField.Label>{fixedLabel}</TextField.Label>
      <TextField.Input />
      {supporting && (
        <TextField.Supporting>{supporting}</TextField.Supporting>
      )}
    </TextField.Root>
  )
}
`,

  placeholderLabel: `
import React, { useState } from "react";
import { TextField } from "@gogipsy/design-system";

export const FixedLabel = () => {
  const [supporting, setSupporting] = useState(null)

  const name = "textfield-name"
  const icon = { name: "Bus", position: "start" }
   const placeholderLabel = "Placeholder Label Text"

  return (
    <TextField.Root name={name} icon={icon}>
     <TextField.Input labe={placeholderLabel} />
      {supporting && (
        <TextField.Supporting>{supporting}</TextField.Supporting>
      )}
    </TextField.Root>
  )
}
`,
}

export const args = {
  fixedLabel: {
    disabled: false,
    status: 'default',
    name: 'textField-fixedLabel',
    iconPosition: 'start',
    label: 'Fixed label',
    placeholderLabel: '',
    supporting: '',
  },
  placeholderLabel: {
    disabled: false,
    status: 'default',
    name: 'textField-placeholderLabel',
    iconPosition: 'start',
    placeholderLabel: 'Placeholder Label example',
    supporting: '',
  },
} satisfies Record<string, Partial<TTextStoryProps>>

export const argTypes = {
  status: {
    control: 'select',
    options: [
      'default',
      'primary',
      'secondary',
      'informative',
      'positive',
      'warning',
      'negative',
    ],
    name: 'status',
    table: {
      category: 'General',
      type: {
        summary: 'status property',
        detail:
          'The status property is used to modify the text field according to the theme colors.\n You can choose between `default`, `primary`, `secondary`, `informative`, `positive`, `warning`, or `negative`.',
      },
      defaultValue: { summary: '' },
    },
  },
  disabled: {
    name: 'disabled',
    control: {
      type: 'boolean',
    },
    table: {
      category: 'General',
      type: {
        summary: 'disabled property',
        detail: 'You can use the disabled property to disable the text field.',
      },
      defaultValue: { summary: false },
    },
  },
  name: {
    name: 'name',
    control: {
      type: 'text',
    },
    table: {
      category: 'General',
      type: {
        summary: 'name property',
        detail:
          'The name property should be included for the identification of the text field; it must be unique per page.',
      },
      defaultValue: { summary: '' },
    },
  },
  label: {
    name: 'label',
    control: {
      type: 'text',
    },
    table: {
      category: 'Label',
      type: {
        summary: 'Label Component',
        detail:
          'You can include the `<TextField.Label />` component to add a fixed label to the textfield.',
      },
      defaultValue: { summary: undefined },
    },
  },
  placeholderLabel: {
    name: 'label',
    control: {
      type: 'text',
    },
    table: {
      category: 'Label',
      type: {
        summary: 'Textfield Label',
        detail:
          'You can include the label property in the `<TextField.Input />` component to add a placeholder label.',
      },
      defaultValue: { summary: undefined },
    },
  },

  supporting: {
    name: 'Supporting',
    control: {
      type: 'text',
    },
    table: {
      category: 'Supporting',
      type: {
        summary: 'supporting Component',
        detail:
          'You can add a <TextField.Supporting> component to include supporting text.',
      },
      defaultValue: { summary: undefined },
    },
  },

  iconName: {
    name: 'name',
    control: 'select',
    options: Object.keys(iconsLucide),
    table: {
      category: 'Icon',
      type: {
        summary: 'Textfield Icon',
        detail:
          'You can use any of the predefined icons.\nFor more information, visit `https://lucide.dev/icons/`.',
      },
      defaultValue: { summary: undefined },
    },
  },
  iconPosition: {
    name: 'position',
    options: ['start', 'end'],
    control: {
      type: 'inline-radio',
    },
    table: {
      category: 'Icon',
      type: {
        summary: 'Position of textfield Icon',
        detail:
          'ou can position the icon at the start or end of the text field using `start` or `end`.',
      },
      defaultValue: { summary: undefined },
    },
  },
} satisfies Partial<ArgTypes<TTextStoryProps>>

export const parameters = {
  design: [
    {
      name: 'Anatomy',
      type: 'figspec',
      url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2265-684&mode=design&t=x6tKFfKtke6ye9tM-4',
      accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
    },
    {
      name: 'Measurements',
      type: 'figspec',
      url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2388-842&mode=design&t=9pcxKp4ZbLw5hwhU-4',
      accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
    },
  ],
} satisfies Parameters
