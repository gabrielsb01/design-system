import { DataPicke } from '@gogipsy/design-system'

export const DataPickerBase = () => {
  return (
    <div className=" flex w-full flex-col gap-4 max-w-[900px]">
      <DataPicke.Root
        name="example"
        mode="range"
        subtextVariations={{
          BRL: 'Valores em Reais (R$)',
          USD: 'Valores em Dolar ($)',
          EUR: 'Valores em Euro (€)',
        }}
        outsideDays
        numberOfMonths={2}
        disabled={{
          before: '2024-03-02',
        }}
        highlight={'2024-03-03'}
        subtext={[
          {
            date: '2024-04-01',
            value: {
              BRL: '100,00',
              USD: '500,00',
              EUR: '50,00',
            },
          },
          { date: '2024-03-03', value: '8,26' },
        ]}
      />
    </div>
  )
}
