import { Meta, StoryObj } from '@storybook/react'

import { argTypes, parameters, sourceExample } from './config'
import { DataPickerBase } from './DataPickerBase'

const storyMeta: Meta = {
  title: 'Form/DataPicker',
  tags: ['autodocs'],
  argTypes,
  parameters,
}

export default storyMeta

export const FixedLabel: StoryObj = {
  parameters: {
    docs: {
      source: {
        code: sourceExample.fixedLabel,
      },
    },
  },
  render: () => <DataPickerBase />,
}
