import type { TTextStoryProps } from '@gogipsy/design-system'

import { TextField } from '@gogipsy/design-system'

export const TextFieldBase = ({
  name,
  iconName,
  iconPosition,
  label,
  placeholderLabel,
  supporting,
  ...rest
}: TTextStoryProps) => {
  const icon = iconName ? { name: iconName, position: iconPosition } : undefined

  return (
    <div className=" flex w-full max-w-[600px] flex-col gap-4">
      <TextField.Root name={name} icon={icon}>
        {label && <TextField.Label>{label}</TextField.Label>}
        <TextField.Input
          label={placeholderLabel}
          {...rest}
          autoComplete="off"
        />
        {supporting && (
          <TextField.Supporting>{supporting}</TextField.Supporting>
        )}
      </TextField.Root>
    </div>
  )
}
