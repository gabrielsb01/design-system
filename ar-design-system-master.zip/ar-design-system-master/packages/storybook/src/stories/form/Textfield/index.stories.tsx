import type { TTextStoryProps } from '@gogipsy/design-system'

import { Meta, StoryObj } from '@storybook/react'

import { args, argTypes, parameters, sourceExample } from './config'
import { TextFieldBase } from './TextFieldBase'

const storyMeta: Meta<TTextStoryProps> = {
  title: 'Form/Textfield',
  tags: ['autodocs'],
  argTypes,
  parameters,
}

export default storyMeta

export const FixedLabel: StoryObj<TTextStoryProps> = {
  args: args.fixedLabel,
  parameters: {
    docs: {
      source: {
        code: sourceExample.fixedLabel,
      },
    },
  },
  render: (args) => <TextFieldBase {...args} />,
}
export const PlaceholderLabel: StoryObj<TTextStoryProps> = {
  args: args.placeholderLabel,
  parameters: {
    docs: {
      source: {
        code: sourceExample.fixedLabel,
      },
    },
  },
  render: (args) => <TextFieldBase {...args} />,
}
