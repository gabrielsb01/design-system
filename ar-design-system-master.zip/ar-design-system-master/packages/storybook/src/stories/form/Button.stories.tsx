import type { IButtonProps } from '@gogipsy/design-system'

import { Button } from '@gogipsy/design-system'
import { ArrowRight } from '@phosphor-icons/react'
import { Meta, StoryObj } from '@storybook/react'

import { TestButton } from '~/_tests/components/TestButton'

const Test = new TestButton()

const storyMeta: Meta<IButtonProps> = {
  title: 'Form/Button',
  component: Button,
  tags: ['autodocs'],
  args: {
    children: 'enviar',
    size: 'medium',
    variant: 'primary',
    disabled: false,
    outline: false,
    text: false,
    name: 'Button',
  },
  parameters: {
    design: [
      {
        name: 'Anatomy',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2265-684&mode=design&t=x6tKFfKtke6ye9tM-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
      {
        name: 'Measurements',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2388-842&mode=design&t=9pcxKp4ZbLw5hwhU-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
    ],
  },

  argTypes: {
    onClick: {
      action: 'click',
      table: {
        disable: true,
      },
    },
    variant: {
      table: {
        disable: true,
      },
    },
    disabled: {
      control: {
        type: 'boolean',
      },
    },
    outline: {
      control: {
        type: 'boolean',
      },
    },
    size: {
      options: ['small', 'medium', 'large'],
      control: {
        type: 'inline-radio',
      },
    },
  },
}

export default storyMeta

export const Primary: StoryObj<IButtonProps> = {
  args: {
    variant: 'primary',
  },
}

export const Secondary: StoryObj<IButtonProps> = {
  args: {
    variant: 'secondary',
  },
}

export const Informative: StoryObj<IButtonProps> = {
  args: {
    variant: 'informative',
    children: 'Nossos destinos',
  },
}

export const Positive: StoryObj<IButtonProps> = {
  args: {
    variant: 'positive',
    children: 'Buscar passagem',
  },
}

export const Warning: StoryObj<IButtonProps> = {
  args: {
    variant: 'warning',
    children: 'Atualizar cadastro',
  },
}

export const Negative: StoryObj<IButtonProps> = {
  args: {
    variant: 'negative',
    children: 'Cancelar passagem',
  },
}

export const With_icon: StoryObj<IButtonProps> = {
  args: {
    children: (
      <>
        Próximo passo
        <ArrowRight weight="bold" />
      </>
    ),
  },
  argTypes: {
    children: {
      table: {
        disable: true,
      },
    },
  },
}

export const With_test: StoryObj<IButtonProps> = {
  args: {},
  play: Test.testId('ButtonAction').run,
}
