import type { ICheckboxProps } from '@gogipsy/design-system'

import { Checkbox } from '@gogipsy/design-system'
import { Meta, StoryObj } from '@storybook/react'

import { TestCheckBox } from '~/_tests/components/TestCheckbox'

const Test = new TestCheckBox({ defaultStatus: false })

const storyMeta: Meta<ICheckboxProps> = {
  title: 'Form/Checkbox',
  component: Checkbox,
  tags: ['autodocs'],
  args: {
    name: 'checkbox',
    variant: 'primary',
    defaultChecked: false,
    indeterminate: false,
    disabled: false,
    value: 'Checkbox',
  },
  argTypes: {},
  parameters: {
    design: [
      {
        name: 'Anatomy',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2265-684&mode=design&t=x6tKFfKtke6ye9tM-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
      {
        name: 'Measurements',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2388-842&mode=design&t=9pcxKp4ZbLw5hwhU-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
    ],
  },
}

export default storyMeta

export const Primary: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'primary',
  },
}
export const Secondary: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'secondary',
  },
}
export const Informative: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'informative',
  },
}
export const Positive: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'positive',
  },
}
export const Warning: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'warning',
  },
}
export const Negative: StoryObj<ICheckboxProps> = {
  args: {
    variant: 'negative',
  },
}
export const With_tests: StoryObj<ICheckboxProps> = {
  args: {},
  play: Test.testId('checkboxInput').run,
}
