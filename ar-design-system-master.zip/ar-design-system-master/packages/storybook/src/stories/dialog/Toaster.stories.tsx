import type { ToasterProps } from '@gogipsy/design-system'

import { Button, toast, Toaster } from '@gogipsy/design-system'
import { Meta, StoryObj } from '@storybook/react'

const storyMeta: Meta<ToasterProps> = {
  title: 'Dialog/Toaster',
  component: Toaster,
  args: {
    position: 'top-right',
    expand: false,
  },

  argTypes: {
    position: {
      options: [
        'top-left',
        'top-center',
        'top-right',
        'bottom-left',
        'bottom-center',
        'bottom-right',
      ],

      control: {
        type: 'inline-radio',
      },
    },
  },
  parameters: {
    design: [
      {
        name: 'Anatomy',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2265-684&mode=design&t=x6tKFfKtke6ye9tM-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
      {
        name: 'Measurements',
        type: 'figspec',
        url: 'https://www.figma.com/file/GwglXp8FSDaNSO1kfzKm33/%F0%9F%8E%A8-%E2%9A%99%EF%B8%8F-Design-System?type=design&node-id=2388-842&mode=design&t=9pcxKp4ZbLw5hwhU-4',
        accessToken: 'figd_PIaXepaiSVYehfPkUV3JrU6fUQBU8rDuLWxy_hsn',
      },
    ],
  },
}

export default storyMeta

export const Basic: StoryObj<ToasterProps> = {
  decorators: [
    (Story) => (
      <>
        <Story />
        <div className="m-auto mt-56 grid max-w-2xl grid-cols-4 gap-4">
          <Button
            name="Default-Toast"
            className="flex-1"
            variant="primary"
            outline
            onClick={() => {
              toast.message(
                'Snackbar text',
                //   {
                //   description: 'Monday, January 3rd at 6:00pm',
                // }
              )
            }}
          >
            Default
          </Button>
          <Button
            name="Default-Toast"
            className="flex-1"
            variant="primary"
            onClick={() => {
              toast.primary('Snackbar text')
            }}
          >
            Primary
          </Button>
          <Button
            name="Default-Toast"
            className="flex-1"
            variant="secondary"
            onClick={() => {
              toast.secondary('Snackbar text')
            }}
          >
            Secondary
          </Button>
          <Button
            name="Default-Toast"
            className="flex-1"
            variant="informative"
            onClick={() => {
              toast.informative('ESnackbar text')
            }}
          >
            Informative
          </Button>
          <Button
            name="Default-Toast"
            className="flex-1"
            variant="positive"
            onClick={() => {
              toast.positive('Snackbar text')
            }}
          >
            Positive
          </Button>

          <Button
            name="Default-Toast"
            className="flex-1"
            variant="warning"
            onClick={() => {
              toast.warning('Snackbar text')
            }}
          >
            Warning
          </Button>

          <Button
            name="Default-Toast"
            className="flex-1"
            variant="negative"
            onClick={() => {
              toast.negative('Snackbar text')
            }}
          >
            Negative
          </Button>
        </div>
      </>
    ),
  ],
}
