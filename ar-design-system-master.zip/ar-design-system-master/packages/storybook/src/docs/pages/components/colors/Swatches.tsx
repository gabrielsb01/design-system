import { iconsLucide } from '@gogipsy/design-system'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from 'shadcn/ui/accordion'

const { AlertTriangle } = iconsLucide
export function ColorsSwatches() {
  return (
    <Accordion type="single" collapsible className="!mb-4">
      <AccordionItem
        value="swatches"
        className="border-bg-grey-700 dark:border-bg-grey-100 last:border-none"
      >
        <AccordionTrigger className="origin-left select-none justify-start gap-2 py-2 pl-2 text-xl font-bold !outline-none hover:scale-105">
          <AlertTriangle className="h-5 w-5" /> Swatches
        </AccordionTrigger>
        <AccordionContent className="!mb-4 rounded-md border border-zinc-400 px-6 py-4">
          <p className="!mx-0 !mb-4 !mt-0 !text-base">
            Use the swatches below to determine the accessibility of the palette
            colour in contrast to the background colour of this page:
          </p>
          <ul className="!m-0 flex flex-col gap-2 !p-0">
            <li className="flex list-none items-center gap-2">
              <span className="w-14 rounded-md bg-neutral-200 p-2 text-center font-bold text-zinc-700">
                AAA
              </span>
              <p className="!m-0 !text-base">
                Regular sized text on this colour will have a contrast ratio of
                4.5:1 or over
              </p>
            </li>
            <li className="flex list-none items-center gap-2">
              <span className="w-14 rounded-md bg-neutral-200 p-2 text-center font-bold text-zinc-700">
                AA
              </span>
              <p className="!m-0 !text-base">
                Regular sized text on this colour will have a contrast ratio of
                3:1 or over
              </p>
            </li>
            <li className="flex list-none items-center gap-2">
              <span className="w-14 rounded-md bg-neutral-200 p-2 text-center font-bold text-zinc-700">
                !
              </span>
              <p>Regular sized text on this colour will be inaccessible</p>
            </li>
          </ul>

          <div className="!mt-10 flex flex-col gap-10">
            <div className="bg-bg-secondary-500 flex flex-col gap-4 rounded-md p-4">
              <p className="!m-0 !text-base !text-zinc-50">
                The{' '}
                <a
                  href="https://www.w3.org/TR/WCAG20-TECHS/G18.html"
                  target="_blank"
                  rel="noreferrer"
                  className="!text-slate-50 !underline"
                >
                  WCAG AA
                </a>{' '}
                standards define regular and large text sizes as:
              </p>
              <p className="!m-0 flex flex-col !text-base !text-zinc-50">
                <strong>Regular</strong>
                Font size is at least 19px with a regular font weight or
                heavier.
              </p>
              <p className="!m-0 !text-base !text-zinc-50">
                <strong>Large</strong>
                Font size is at least 19px with a bold font weight or 24px with
                regular font weight.
              </p>
            </div>
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  )
}
