import type { TTokens } from '@gogipsy/ds-tokens'

import { twMerge } from 'tailwind-merge'

import { formatBorderStyle } from '~/utils/tokens/border'
import { parseRemToPx } from '~/utils/tokens/space'

import { CopyButton } from '../ui/CopyButton'

interface IFontProps {
  fontToken: TTokens
  styleProp: string
  showPx?: boolean
}

export function Typography({
  fontToken,
  styleProp,
  showPx = false,
}: IFontProps) {
  const fontStyles = formatBorderStyle(fontToken, styleProp)

  const colsClass = showPx ? 'grid-cols-4' : 'grid-cols-3'

  return (
    <div className="flex w-full flex-col">
      <div
        className={twMerge('grid w-full grid-cols-4 border-b pb-4', colsClass)}
      >
        <p className="!m-0 flex-1 !text-lg !font-bold">Result</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token value</p>
        {showPx && (
          <p className="!m-0 flex-1 !text-lg !font-bold">Token value in PX</p>
        )}
      </div>
      {Object.entries(fontStyles).map(([key, data]) => (
        <div
          key={key}
          className={twMerge(
            'grid w-full grid-cols-4 gap-4 border-b border-zinc-300 py-4',
            colsClass,
          )}
        >
          <div className="flex gap-5 overflow-hidden">
            <p style={data.style} className="text-nowrap">
              The quick brown fox jumps over the lazy dog
            </p>
          </div>
          <CopyButton
            name={`typography${styleProp}-${key}-token`}
            value={`$${key}`}
            size="small"
            variant="primary"
            className="my-auto"
          >
            ${key}
          </CopyButton>
          <CopyButton
            name={`typography${styleProp}-${key}-value`}
            value={data.value.toString()}
            size="small"
            variant="secondary"
            className="my-auto"
          >
            {data.value}
          </CopyButton>
          {showPx && (
            <CopyButton
              value={`${parseRemToPx(data.value)}px`}
              name={`typography${styleProp}-${key}-px`}
              size="small"
              variant="informative"
              className="my-auto"
            >
              {parseRemToPx(data.value)}px
            </CopyButton>
          )}
        </div>
      ))}
    </div>
  )
}
