import { memo, useEffect } from 'react'

import { useColors } from '#/store/tokens/useColors'

import {
  generateColorVariations,
  getKeyColorByPath,
} from '~/utils/tokens/colors'

import { ColorSelect } from '../components/ColorSelect'
import { useColorSelect } from '../components/ColorSelect/useColorSelect'

type TShaderSelect = {
  path: string
}

const updateColors = useColors.getState().actions.updateColors
const defaultColors = useColors.getState().data.colors

export const ShaderSelect = memo<TShaderSelect>(({ path }) => {
  const color = useColorSelect((st) => st.data.colors[path])
  const pathKey = getKeyColorByPath(path)

  useEffect(() => {
    if (color) {
      const newColor: Record<string, string> = {}
      newColor[pathKey] = color.hex

      updateColors(newColor)
      generateColorVariations(path, color.hex)
    }
  }, [color])

  return <ColorSelect name={path} defaultColor={defaultColors[pathKey]} />
})

ShaderSelect.displayName = 'ShaderSelect'
