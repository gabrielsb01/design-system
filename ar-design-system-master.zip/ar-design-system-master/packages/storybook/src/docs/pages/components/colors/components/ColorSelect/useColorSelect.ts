import type {
  TColorSelectStore,
  TColorSelectStoreData,
} from '@/docs/pages/components/colors/components/colorSelect'

import { produce } from 'immer'
import { create } from 'zustand'

import { hexConvert } from '~/utils/tokens/colors'

const defaultData: TColorSelectStoreData = {
  colors: {},
}

export const useColorSelect = create<TColorSelectStore>((set) => ({
  data: defaultData,
  actions: {
    register: (name, hex) =>
      set((state) =>
        produce(state, (draft) => {
          if (state.data.colors[name]) return

          draft.data.colors[name] = hexConvert(hex)
        }),
      ),
    setColor: (name, color) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data.colors[name]) return

          draft.data.colors[name] = color
        }),
      ),
  },
}))
