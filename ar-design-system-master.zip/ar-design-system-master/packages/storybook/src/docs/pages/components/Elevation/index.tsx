import { shadows } from '@gogipsy/ds-tokens'

import { CopyButton } from '../ui/CopyButton'

export function Elevation() {
  return (
    <div className="flex w-full flex-col">
      <div className="grid w-full grid-cols-3 gap-4 border-b border-zinc-300 pb-4">
        <p className="!m-0 flex-1 !text-lg !font-bold">Result</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token value</p>
      </div>
      {Object.entries(shadows).map(([key, boxShadow]) => (
        <div
          key={key}
          className="grid w-full grid-cols-3 gap-4 border-b border-zinc-300 py-4"
        >
          <div
            className="h-20 w-20 rounded-md border-2 border-bg-secondary-600 bg-neutral-200 dark:border-bg-primary-600"
            style={{ boxShadow }}
          />
          <CopyButton
            value={`$${key}`}
            name={`elevation-boxShadow-${key}-token`}
            size="small"
            variant="primary"
            className="flex"
          >
            ${key}
          </CopyButton>
          <CopyButton
            value={boxShadow}
            name={`elevation-boxShadow-${key}-value`}
            size="small"
            variant="secondary"
          >
            {boxShadow}
          </CopyButton>
        </div>
      ))}
    </div>
  )
}
