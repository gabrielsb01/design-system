import type { TIconLib } from '@gogipsy/design-system'

import { iconLibs } from '@gogipsy/design-system'

import { CopyButton } from '../ui/CopyButton'

interface IIconProps {
  lib: TIconLib
}

export function Icon({ lib = 'lucide' }: IIconProps) {
  const iconLib = iconLibs[lib]
  const Icon = iconLib.icon

  return (
    <div className="w-full">
      <p className="flex items-center gap-2 !text-2xl !font-bold">
        {Icon && <Icon />}
        {iconLib.title}
      </p>
      {iconLib.description && (
        <p className="!text-base !font-normal">{iconLib.description}</p>
      )}
      <div className="flex flex-wrap gap-4">
        {Object.entries(iconLib.icons).map(([name, LibIcon]) => (
          <CopyButton
            key={`key-${lib}-${name}`}
            name={`icon-${lib}-${name}`}
            value={name}
            outline
            size="medium"
            variant="informative"
          >
            <LibIcon />
          </CopyButton>
        ))}
      </div>
    </div>
  )
}
