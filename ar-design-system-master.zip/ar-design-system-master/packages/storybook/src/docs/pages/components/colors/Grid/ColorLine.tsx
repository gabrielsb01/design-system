import { useColors } from '#/store/tokens/useColors'

import { getColorByContrast, getContrastAA } from '~/utils/tokens/colors'

import { CopyButton } from '../../ui/CopyButton'

type TColorLine = {
  colorKey: string
}

export function ColorLine({ colorKey }: TColorLine) {
  const textBaseKeys = {
    light: 'neutral-gray-900',
    dark: 'neutral-gray-50',
  }

  const textLightColor = useColors((st) => st.data.colors[textBaseKeys.light])
  const textDarkColor = useColors((st) => st.data.colors[textBaseKeys.dark])
  const color = useColors((st) => st.data.colors[colorKey])

  return (
    <li
      data-type="color"
      className="group !m-0 flex items-center justify-between gap-4 bg-red-300 px-4 py-2 transition-all first:rounded-t-md last:rounded-b-md hover:scale-[1.025] hover:rounded-md hover:shadow-md"
      style={{ background: color }}
    >
      <CopyButton
        asChild
        name="color-tokne-Blue010"
        value={colorKey}
        className="h-full p-2 text-base outline-none transition-all hover:scale-105 hover:font-bold"
        style={{
          color: getColorByContrast(color, [textDarkColor, textLightColor]),
        }}
      >
        <button>${colorKey}</button>
      </CopyButton>
      <div className="flex items-center gap-4">
        <CopyButton
          asChild
          name={`color-code-${color}`}
          value={color.toUpperCase()}
          className="h-full p-2 text-base outline-none transition-all hover:scale-105 hover:font-bold"
          style={{
            color: getColorByContrast(color, [textDarkColor, textLightColor]),
          }}
        >
          <button>{color.toUpperCase()}</button>
        </CopyButton>
        <div className="flex items-center gap-3">
          <span className="w-14 rounded-md bg-white/30 text-center text-base font-bold !text-bg-grey-900">
            {getContrastAA(color, textDarkColor)}
          </span>
          <span className="w-14 rounded-md bg-black/30 text-center text-base  font-bold  !text-bg-grey-50">
            {getContrastAA(color, textLightColor)}
          </span>
        </div>
      </div>
    </li>
  )
}
