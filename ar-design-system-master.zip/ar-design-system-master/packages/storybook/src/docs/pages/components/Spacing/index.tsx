import { space } from '@gogipsy/ds-tokens'

import { parseRemToPx, sortSpaces } from '~/utils/tokens/space'

import { CopyButton } from '../ui/CopyButton'

const sortedSpaces = sortSpaces(space)

export function Spacing() {
  return (
    <div className="flex w-full flex-col">
      <div className="grid w-full grid-cols-6 gap-4 border-b border-zinc-300 pb-4">
        <p className="!m-0 flex-1 !text-lg !font-bold">Token</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token value</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token value in PX</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Result</p>
      </div>
      {sortedSpaces.map(([key, width]) => (
        <div
          key={key}
          className="grid w-full grid-cols-6 gap-4 border-b border-zinc-300 py-4"
        >
          <CopyButton
            value={`$${key}`}
            name={`spacing-width-${key}-token`}
            size="small"
            variant="primary"
            className="my-auto"
          >
            ${key}
          </CopyButton>
          <CopyButton
            value={width}
            name={`spacing-width-${key}-value`}
            size="small"
            variant="secondary"
            className="my-auto"
          >
            {width}
          </CopyButton>

          <CopyButton
            value={`${parseRemToPx(width)}px`}
            name={`spacing-width-${key}-value`}
            size="small"
            variant="informative"
            className="my-auto"
          >
            {parseRemToPx(width)}px
          </CopyButton>
          <div className="col-span-3 flex items-center pr-6">
            <div
              className="bottom h-4 rounded-md border-zinc-100/40 bg-neutral-200 shadow-md"
              style={{ width }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}
