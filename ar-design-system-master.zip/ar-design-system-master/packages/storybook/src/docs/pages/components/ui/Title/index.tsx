export function Title({ children }: { children: string }) {
  return (
    <h1 className="relative w-full pb-4 !text-5xl font-bold">{children}</h1>
  )
}
