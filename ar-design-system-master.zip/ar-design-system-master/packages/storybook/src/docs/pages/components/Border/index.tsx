import type { TTokens } from '@gogipsy/ds-tokens'

import { formatBorderStyle } from '~/utils/tokens/border'

import { CopyButton } from '../ui/CopyButton'

interface IBorderProps {
  borderToken: TTokens
  styleProp: string
  rectangle?: boolean
}

export function Border({
  borderToken,
  styleProp,
  rectangle = false,
}: IBorderProps) {
  const borderStyles = formatBorderStyle(borderToken, styleProp)

  return (
    <div className="flex w-full flex-col">
      <div className="grid w-full grid-cols-3 gap-4 border-b pb-4">
        <p className="!m-0 flex-1 !text-lg !font-bold">Result</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token</p>
        <p className="!m-0 flex-1 !text-lg !font-bold">Token value</p>
      </div>
      {Object.entries(borderStyles).map(([key, data]) => (
        <div key={key} className="grid w-full grid-cols-3 gap-4 border-b py-4">
          <div className="flex gap-5">
            <div
              className="h-20 w-20 rounded-md border-4 border-bg-secondary-600 bg-neutral-200 dark:border-bg-primary-600"
              style={data.style}
            />
            {rectangle && (
              <div
                className="h-20 w-40 rounded-md border-4 border-bg-secondary-600 bg-neutral-200 dark:border-bg-primary-600"
                style={data.style}
              />
            )}
          </div>
          <CopyButton
            name={`button-${styleProp}-${key}-token`}
            value={`$${key}`}
            size="small"
            variant="primary"
            className="my-auto"
          >
            ${key}
          </CopyButton>
          <CopyButton
            name={`button-${styleProp}-${key}-value`}
            value={data.value.toString()}
            size="small"
            variant="secondary"
            className="my-auto"
          >
            {data.value}
          </CopyButton>
        </div>
      ))}
    </div>
  )
}
