import type { IColorsDataScale } from '@gogipsy/ds-tokens'

import { memo } from 'react'

import { getKeysByPath } from '~/utils/tokens/colors'

import { ColorLine } from './ColorLine'

type TGridColorScale = {
  scale: IColorsDataScale
}

export const GridColorScale = memo<TGridColorScale>(({ scale }) => {
  const colors = getKeysByPath(scale.path)
  // console.log(JSON.stringify(colors))
  return (
    <div
      key={scale.title}
      className="flex min-w-full flex-1 flex-col lg:min-w-[450px]"
    >
      <p className="!m-0 !text-xl font-bold">{scale.title}</p>
      <ul className="flex w-full flex-1 flex-col !p-0">
        {colors.map((colorKey) => (
          <ColorLine key={colorKey} colorKey={colorKey} />
        ))}
      </ul>
    </div>
  )
})

GridColorScale.displayName = 'GridColorScale'
