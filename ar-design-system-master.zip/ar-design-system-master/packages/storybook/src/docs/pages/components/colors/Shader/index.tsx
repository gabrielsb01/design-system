import { ShaderSelect } from './ShaderSelect'

export function ColorsShader() {
  return (
    <form className="mb-10  flex w-full flex-col gap-2 rounded-md border border-zinc-100/50 bg-white/30 p-4 shadow-md">
      <h3 className="!text-2xl font-bold">Color palettes </h3>
      <div className="flex w-full flex-wrap gap-8">
        <div className="flex flex-col gap-2">
          <p className="!m-0">Brand Primary Color</p>
          <ShaderSelect path="brand.primary" />
        </div>
        <div className="flex flex-col gap-2">
          <p className="!m-0">Brand Secondary Color</p>
          <ShaderSelect path="brand.secondary" />
        </div>
      </div>
    </form>
  )
}
