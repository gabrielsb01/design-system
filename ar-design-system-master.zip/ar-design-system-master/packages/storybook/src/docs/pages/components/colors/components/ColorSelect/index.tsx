import type { TColorSelectProps } from '@/docs/pages/components/colors/components/colorSelect'

import { Button } from '@gogipsy/design-system'
import { Popover, PopoverContent, PopoverTrigger } from 'shadcn/ui/popover'

import { ColorPicker } from '../ColorPicker'

import { useColorSelect } from './useColorSelect'

export function ColorSelect({
  name,
  defaultColor = '#FFFFFF',
}: TColorSelectProps) {
  const register = useColorSelect((st) => st.actions.register)
  const setColor = useColorSelect((st) => st.actions.setColor)

  const color = useColorSelect((st) => st.data.colors[name])

  if (!color)
    return (
      <Button
        name={name}
        outline
        size="medium"
        variant="informative"
        type="button"
        onClick={() => {
          register(name, defaultColor)
        }}
      >
        Choose Color...
      </Button>
    )

  return (
    <Popover defaultOpen>
      <PopoverTrigger className="flex w-40 items-center gap-4 rounded-md border border-zinc-400 p-2 pr-3 !text-base font-bold uppercase outline-none">
        <span
          style={{ background: color.hex }}
          className="h-8 w-10 rounded-sm border border-zinc-400"
        />
        {color.hex}
      </PopoverTrigger>
      <PopoverContent className="w-fit p-2" align="start">
        <ColorPicker
          color={color.hex}
          onChange={(color) => {
            setColor(name, color)
          }}
          theme={{
            borderColor: 'transparent',
            background: 'transparent',
            boxShadow: 'node',
          }}
        />
      </PopoverContent>
    </Popover>
  )
}
