import { colors, descriptions } from '@gogipsy/ds-tokens'

import { useColors } from '#/store/tokens/useColors'

import { GridColorScale } from './ColorScale'

const setStartColors = useColors.getState().actions.setColors

const colorsDescriptions = descriptions.colors.descriptions

setStartColors(colors)

export function ColorsGrid() {
  return (
    <div className="flex w-full flex-col gap-14">
      {Object.keys(colorsDescriptions).map((key) => (
        <div
          key={key}
          className="flex w-full flex-col gap-2 rounded-md border border-zinc-100/50 bg-white/30 p-4 shadow-md"
        >
          <div className="mb-3 flex w-full flex-wrap">
            <h1 className="m-0 flex w-full !text-4xl font-bold">
              {colorsDescriptions[key].title}
            </h1>
            <p className="!text-lg">{colorsDescriptions[key].description}</p>
          </div>
          <div className="flex w-full flex-wrap gap-5 pl-5">
            {colorsDescriptions[key].scales.map((scale) => (
              <GridColorScale key={scale.path} scale={scale} />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
