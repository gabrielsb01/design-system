import type { IButtonProps } from '@gogipsy/design-system'

import { useEffect, useState } from 'react'

import { Button } from '@gogipsy/design-system'
import { Check } from '@phosphor-icons/react'
import { Slot, Slottable } from '@radix-ui/react-slot'
import copy from 'copy-to-clipboard'
import { twMerge } from 'tailwind-merge'

interface ICopyButton extends Omit<IButtonProps, 'onClick'> {
  asChild?: boolean
  value: string
  name: string
}

export function CopyButton({
  name,
  value,
  children,
  className,
  asChild,
  ...rest
}: ICopyButton) {
  const [showBubble, setShowBubble] = useState(false)
  const Comp = asChild ? Slot : Button
  const bubble = showBubble ? 'opacity-100' : 'opacity-0'

  const copyContent = () => {
    copy(value)
    setShowBubble(true)
  }

  useEffect(() => {
    if (showBubble) {
      setTimeout(() => {
        setShowBubble(false)
      }, 1000)
    }
  }, [showBubble])

  return (
    <Comp
      {...rest}
      name={name}
      className={twMerge('group relative', className)}
      onClick={copyContent}
    >
      <div
        className={twMerge(
          'pointer-events-none absolute -top-1/2 flex -translate-y-1/2 items-center gap-1 rounded-md bg-emerald-500 py-1 pl-2 pr-3 !text-sm text-zinc-50 opacity-0 transition-all duration-500 ease-in-out',
          bubble,
        )}
      >
        <Check size={16} className="relative top-[1px]" />
        Copied
        <em className="absolute -bottom-[5px] left-1/2 h-0 w-0 -translate-x-1/2 border-x-[8px] border-t-[6px] border-x-transparent border-t-emerald-500" />
      </div>
      <Slottable>{children}</Slottable>
    </Comp>
  )
}
