import type { ComponentProps } from 'react'

import ReactColorPicker from 'react-pick-color'

type TColorPickerProps = Partial<ComponentProps<typeof ReactColorPicker>>

export function ColorPicker(props: TColorPickerProps) {
  return <ReactColorPicker hideAlpha {...props} />
}
