export function Description({ children }: { children: string }) {
  return <div className="mb-9 flex w-full flex-col gap-1 pb-4">{children}</div>
}
