import type { TColorStore, TColorStoreData } from '@/docs/store/tokens/colors'

import { produce } from 'immer'
import _ from 'lodash'
import { create } from 'zustand'

const defaultData: TColorStoreData = {
  colors: {},
}

export const useColors = create<TColorStore>((set) => ({
  data: defaultData,
  actions: {
    setColors: (colors = false) =>
      set((state) =>
        produce(state, (draft) => {
          draft.data.colors = colors || {}
        }),
      ),
    updateColors: (colors) =>
      set((state) =>
        produce(state, (draft) => {
          draft.data.colors = _.merge({}, state.data.colors, colors)
        }),
      ),
  },
}))
