import { ITestBase, ITestBaseProps, TPlayContext } from '~/@types/_tests/base'

export abstract class TestBase implements ITestBase {
  protected _testId?: string

  constructor(props?: ITestBaseProps) {
    if (!props) return

    this._testId = props.testId
  }

  protected playVoid = async () => new Promise<void>((resolve) => resolve())

  public run = async ({ step }: TPlayContext) => {
    await step('test runner is ready', this.playVoid)
  }

  public testId = (testId: string) => {
    this._testId = testId

    return this
  }
}
