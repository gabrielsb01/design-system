import type { TPlayContext } from '~/@types/_tests/base'

import { expect, userEvent, within } from '@storybook/test'

import { ITestTextField } from '~/@types/_tests/textField'

import { TestBase } from '../TestBase'

export class TestTextField extends TestBase implements ITestTextField {
  private tryClick = async ({
    step,
    element,
    args,
  }: ITextFieldTestStepProps) => {
    await step('it should be able Click', async () => {
      await userEvent.click(element)

      await expect(args.onClick).toBeCalledTimes(1)
    })
  }

  public run = async (playContext: TPlayContext) => {
    if (!this._testId) return

    const canvas = within(playContext.canvasElement as HTMLElement)
    const element = canvas.getByTestId(this._testId)

    const stepProps: ITextFieldTestStepProps = { ...playContext, element }

    await this.tryClick(stepProps)
  }
}
