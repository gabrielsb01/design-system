import type { TPlayContext } from '~/@types/_tests/base'
import type {
  ISwitchTestProps,
  ISwitchTestStepProps,
  ITestSwitch,
} from '~/@types/_tests/switch'

import { expect, userEvent, within } from '@storybook/test'
import _ from 'lodash'

import { toBoolean } from '~/utils/functions'

import { TestBase } from '../TestBase'

export class TestSwitch extends TestBase implements ITestSwitch {
  private readonly _defaultStatus: unknown

  constructor(props: ISwitchTestProps) {
    super(props)
    this._defaultStatus = props.defaultStatus
  }

  private resetSwitchStatus = async (
    element: HTMLElement,
    status?: boolean,
  ) => {
    const resetTo = _.isUndefined(status) ? this._defaultStatus : status
    const currentStatus = toBoolean(element.getAttribute('aria-checked'))

    if (currentStatus === resetTo) return

    await userEvent.click(element)
    const newStatus = toBoolean(element.getAttribute('aria-checked'))

    if (newStatus !== resetTo) {
      throw new Error('Switch: Unable to reset switch status')
    }
  }

  private tryTurnOn = async ({ step, element }: ISwitchTestStepProps) => {
    await this.resetSwitchStatus(element)

    await step('it should be able turn on', async () => {
      await userEvent.click(element)

      await expect(element).toHaveAttribute('aria-checked', 'true')
    })
  }

  private tryTurnOff = async ({ step, element }: ISwitchTestStepProps) => {
    await this.resetSwitchStatus(element, true)

    await step('it should be able turn of', async () => {
      await userEvent.click(element)
      await expect(element).toHaveAttribute('aria-checked', 'false')
    })
  }

  public run = async (playContext: TPlayContext) => {
    if (!this._testId) return

    const canvas = within(playContext.canvasElement as HTMLElement)
    const element = canvas.getByTestId(this._testId)

    const stepProps: ISwitchTestStepProps = { ...playContext, element }

    await this.tryTurnOn(stepProps)
    await this.tryTurnOff(stepProps)
  }
}
