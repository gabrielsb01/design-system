import type { TPlayContext } from '~/@types/_tests/base'
import type { IButtonTestStepProps, ITestButton } from '~/@types/_tests/button'

import { expect, userEvent, within } from '@storybook/test'

import { TestBase } from '../TestBase'

export class TestButton extends TestBase implements ITestButton {
  private tryClick = async ({ step, element, args }: IButtonTestStepProps) => {
    await step('it should be able Click', async () => {
      await userEvent.click(element)

      await expect(args.onClick).toBeCalledTimes(1)
    })
  }

  public run = async (playContext: TPlayContext) => {
    if (!this._testId) return

    const canvas = within(playContext.canvasElement as HTMLElement)
    const element = canvas.getByTestId(this._testId)

    const stepProps: IButtonTestStepProps = { ...playContext, element }

    await this.tryClick(stepProps)
  }
}
