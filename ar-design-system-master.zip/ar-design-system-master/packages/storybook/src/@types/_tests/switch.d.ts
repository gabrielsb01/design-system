import type { ITestBase, ITestBaseProps, TPlayContext } from './base'

export interface ISwitchTestStepProps extends TPlayContext {
  element: HTMLElement
}

export interface ISwitchTestProps extends ITestBaseProps {
  defaultStatus: unknown
}

export type ITestSwitch = ITestBase<ITestSwitch>
