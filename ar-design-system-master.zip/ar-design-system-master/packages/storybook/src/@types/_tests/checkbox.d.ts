import type { ITestBase, ITestBaseProps, TPlayContext } from './base'

export interface ICheckBoxTestStepProps extends TPlayContext {
  element: HTMLElement
}

export interface ICheckBoxTestProps extends ITestBaseProps {
  defaultStatus: unknown
}

export type ITestCheckBox = ITestBase<ITestCheckBox>
