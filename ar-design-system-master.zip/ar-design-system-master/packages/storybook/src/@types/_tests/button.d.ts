import type { ITestBase, ITestBaseProps, TPlayContext } from './base'

export interface IButtonTestStepProps extends TPlayContext {
  element: HTMLElement
}

export type IButtonTestProps = ITestBaseProps

export type ITestButton = ITestBase<ITestButton>
