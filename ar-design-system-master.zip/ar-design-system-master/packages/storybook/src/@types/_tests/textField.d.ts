import type { ITestBase, ITestBaseProps, TPlayContext } from './base'

export interface ITextFieldTestStepProps extends TPlayContext {
  element: HTMLElement
}

export type ITextFieldTestProps = ITestBaseProps

export type ITestTextField = ITestBase<ITestTextField>
