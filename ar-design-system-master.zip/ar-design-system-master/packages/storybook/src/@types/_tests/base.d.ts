import type { PlayFunctionContext } from '@storybook/types'

export type TPlayContext = PlayFunctionContext
export type TTesting = (playContext: TPlayContext) => Promise<void> | void

export interface ITestBase<T = ITestBase> {
  run: (playContext: TPlayContext) => Promise<void> | void
  testId: (testId: string) => T
}

export interface ITestBaseProps {
  testId?: string
}
