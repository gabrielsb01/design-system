export type TColorCategory = {
  [key: string]: string
}
export type TColors = {
  [key: string]: string | TColorCategory
}
