import { z } from 'zod'

export const ZColorStoreColor = z.record(z.string())

export const ZColorStoreData = z.object({
  colors: ZColorStoreColor,
})

export const ZColorStoreActions = z.object({
  setColors: z
    .function()
    .args(z.union([ZColorStoreColor, z.literal(false)]).optional()),
  updateColors: z.function().args(ZColorStoreColor),
})

export const ZColorStore = z.object({
  data: ZColorStoreData,
  actions: ZColorStoreActions,
})

export type TColorStoreColor = z.infer<typeof ZColorStoreColor>
export type TColorStoreData = z.infer<typeof ZColorStoreData>
export type TColorStoreActions = z.infer<typeof ZColorStoreActions>

export type TColorStore = z.infer<typeof ZColorStore>
