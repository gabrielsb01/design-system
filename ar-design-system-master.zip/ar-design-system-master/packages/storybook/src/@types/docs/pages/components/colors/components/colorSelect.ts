import { z } from 'zod'

export const ZColorSelectColorHEX = z.string()
export const ZColorSelectColorRGB = z.object({
  r: z.number(),
  g: z.number(),
  b: z.number(),
  a: z.number(),
})
export const ZColorSelectColorHSL = z.object({
  h: z.number(),
  s: z.number(),
  l: z.number(),
  a: z.number(),
})
export const ZColorSelectColorHSV = z.object({
  h: z.number(),
  s: z.number(),
  v: z.number(),
  a: z.number(),
})
export const ZColorSelectColorAlpha = z.number()

export const ZColorSelectColor = z.union([
  ZColorSelectColorHEX,
  ZColorSelectColorRGB,
  ZColorSelectColorHSL,
  ZColorSelectColorHSV,
])

export const ZColorSelectColorObject = z.object({
  hex: ZColorSelectColorHEX,
  rgb: ZColorSelectColorRGB,
  hsl: ZColorSelectColorHSL,
  hsv: ZColorSelectColorHSV,
  alpha: ZColorSelectColorAlpha,
})

export const ZColorSelectStoreData = z.object({
  colors: z.record(ZColorSelectColorObject),
})

export const ZColorSelectStoreActions = z.object({
  register: z
    .function()
    .args(z.string(), ZColorSelectColorHEX)
    .returns(z.void()),
  setColor: z
    .function()
    .args(z.string(), ZColorSelectColorObject)
    .returns(z.void()),
})

export const ZColorSelectStore = z.object({
  data: ZColorSelectStoreData,
  actions: ZColorSelectStoreActions,
})

export const ZColorSelectProps = z.object({
  name: z.string(),
  defaultColor: z.string().optional(),
})

export type TColorSelectColorHEX = z.infer<typeof ZColorSelectColorHEX>
export type TColorSelectColorRGB = z.infer<typeof ZColorSelectColorRGB>
export type TColorSelectColorHSL = z.infer<typeof ZColorSelectColorHSL>
export type TColorSelectColorHSV = z.infer<typeof ZColorSelectColorHSV>
export type TColorSelectColorAlpha = z.infer<typeof ZColorSelectColorAlpha>

export type TColorSelectColor = z.infer<typeof ZColorSelectColor>
export type TColorSelectColorObject = z.infer<typeof ZColorSelectColorObject>

export type TColorSelectStoreData = z.infer<typeof ZColorSelectStoreData>
export type TColorSelectStoreActions = z.infer<typeof ZColorSelectStoreActions>
export type TColorSelectStore = z.infer<typeof ZColorSelectStore>

export type TColorSelectProps = z.infer<typeof ZColorSelectProps>
