import { TTokens } from '@gogipsy/ds-tokens'
import _ from 'lodash'

export function formatBorderStyle(
  borderTokens: TTokens,
  styleAttribute: string,
) {
  const borderStyles = _.mapValues(borderTokens, (value) => {
    return {
      value,
      style: {
        [styleAttribute]: value,
      },
    }
  })

  return borderStyles
}
