import type { IColorsDataScale } from '@gogipsy/ds-tokens'

import { colors, descriptions } from '@gogipsy/ds-tokens'
import {
  argbFromHex,
  hexFromArgb,
  themeFromSourceColor,
} from '@material/material-color-utilities'
import chroma from 'chroma-js'
import _ from 'lodash'
import { getContrast } from 'polished'

import { useColors } from '#/store/tokens/useColors'

const scaleIndexes = descriptions.colors.config.scaleIndexes
const colorDescriptions = descriptions.colors.descriptions

export function getContentByPath(path: string) {
  const objColors = useColors.getState().data.colors

  if (path === '.') {
    return _.pickBy(objColors, (value) => typeof value === 'string') as Record<
      string,
      string
    >
  }

  const content = _.get(objColors, path)
  const pathKey = getKeyColorByPath(path)

  return _.mapKeys(content, (_, key) => `${pathKey}-${key}`) as Record<
    string,
    string
  >
}

export function getKeysByPath(path: string) {
  if (path === '.') {
    return _.filter(_.keys(colors), (key) => !/\d/.test(key))
  }

  const pathKey = getKeyColorByPath(path)
  return scaleIndexes.map((index) => `${pathKey}-${index}`)
}

export function getContrastAA(color1: string, color2: string) {
  const contrast = getContrast(color1, color2)
  if (contrast >= 4.5) return 'AAA'
  if (contrast >= 3) return 'AA'
  return '!'
}

export function getColorByContrast(color1: string, options: string[]) {
  const contrast = getContrast(color1, options[0])
  if (contrast >= 4.5) return options[0]
  return options[1]
}

export function parsePathToToken(
  scale: IColorsDataScale,
  index: number,
  prefix = '$',
) {
  if (scale.path !== '.') {
    return prefix + scale.path.replace(/\./g, '-') + '-' + scaleIndexes[index]
  }
  if (!scale.indexes) return ''
  if (!scale.indexes[index]) return prefix + index

  const tokenVar = scale.indexes[index].replace(/\./g, '-')
  return prefix + tokenVar
}

// const tons = [98, 95, 82, 70, 60, 54.3, 49.5, 44, 38, 27]

function getMinTone(tone: number) {
  while (tone > 10) tone /= 1.61803398875

  if (tone < 9.6) return 9.6

  return tone
}

function generateLogarithmicSequence(X: number) {
  const sequence = [X]

  for (let i = 1; i < 10; i++) {
    const nextNumber = sequence[i - 1] * Math.log(X)

    if (nextNumber > 75) {
      sequence.push(sequence[i - 1] * (Math.log(X) / 2))
      continue
    }

    if (nextNumber > 50) {
      sequence.push(sequence[i - 1] * (Math.log(X) / 1.5))
      continue
    }

    if (nextNumber > 25) {
      sequence.push(sequence[i - 1] * (Math.log(X) / 1.25))
      continue
    }

    sequence.push(nextNumber)
  }

  return sequence
}

export function createColorScale(base: string) {
  const m3ThemeColorsJSON = themeFromSourceColor(argbFromHex(base))
  const tons = generateLogarithmicSequence(
    getMinTone(m3ThemeColorsJSON.palettes.primary.keyColor.tone / 1.96),
  )

  return tons.map((ton) =>
    hexFromArgb(m3ThemeColorsJSON.palettes.primary.tone(ton)),
  )
}

export function createThemColors(
  basePath: string,
  colors: string[],
): Record<string, string> {
  const coresObjeto = _.map(colors, (color, i) => [
    `${basePath}-${scaleIndexes[i]}`,
    color,
  ])

  return _.fromPairs(coresObjeto)
}

export function getKeyColorByPath(path: string) {
  return path.replace(/\./g, '-') as keyof typeof colors
}

export function getDefaultColorByPath(path: string) {
  const pathKey = getKeyColorByPath(path)

  if (colors[pathKey]) return colors[pathKey]
}

export function hexConvert(color: string) {
  const hex = chroma(color).hex()
  const alpha = chroma(color).alpha()

  const rgbaValues = chroma(color).rgb()
  const hslValues = chroma(color).hsl()
  const hsvValues = chroma(color).hsv()

  const rgb = {
    r: rgbaValues[0],
    g: rgbaValues[1],
    b: rgbaValues[2],
    a: alpha,
  }
  const hsl = {
    h: hslValues[0],
    s: hslValues[1],
    l: hslValues[2],
    a: alpha,
  }
  const hsv = {
    h: hsvValues[0],
    s: hsvValues[1],
    v: hsvValues[2],
    a: alpha,
  }

  return { hex, rgb, hsl, hsv, alpha }
}

export function generateColorVariations(path: string, base?: string) {
  if (!base) {
    const defaultColor = getDefaultColorByPath(path)
    if (!defaultColor) return null

    base = defaultColor
  }

  const updateColors = useColors.getState().actions.updateColors

  const colorScaleProps = _.find(colorDescriptions.brand.scales, { path })
  if (!colorScaleProps) return

  const pathKey = getKeyColorByPath(colorScaleProps.path)
  const colorScale = createColorScale(base)

  const objectColorScale = createThemColors(pathKey, colorScale)

  updateColors(objectColorScale)
}
