export function parseRemToPx(rem: unknown) {
  const remValue = String(rem)
  const unit = remValue.replace(/\d+/g, '')
  const remNumber = parseFloat(remValue.replace(/[a-zA-Z]/g, ''))

  if (unit === 'px') return remNumber

  return remNumber * 16
}

export function sortSpaces(spaces: Record<string, string>) {
  const spaceArray = Object.entries(spaces)

  const customSortOrder = (a: [string, string], b: [string, string]) => {
    const valueA = a[1]
    const valueB = b[1]

    if (valueA === '0px') return -Infinity
    if (valueB === '0px') return Infinity

    if (valueA === '1px') return -1
    if (valueB === '1px') return 1

    return parseFloat(valueA) - parseFloat(valueB)
  }

  const spaceArraySorted = spaceArray.sort(customSortOrder)

  return spaceArraySorted
}
