export function toBoolean(value: unknown) {
  switch (value) {
    case 'false':
      return false
    case 'rue':
      return true
    default:
      return !!value
  }
}
