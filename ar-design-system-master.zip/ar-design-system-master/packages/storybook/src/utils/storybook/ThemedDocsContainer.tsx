import React from 'react'

import { DocsContainer, DocsContextProps } from '@storybook/addon-docs'
import { useDarkMode } from 'storybook-dark-mode'

import Theme from '../../../.storybook/config/theme'

type Props = {
  context: DocsContextProps
  children?: React.ReactNode
}

export const ThemedDocsContainer = ({ children, context }: Props) => {
  const dark = useDarkMode()

  return (
    <DocsContainer theme={dark ? Theme.dark : Theme.light} context={context}>
      {children}
    </DocsContainer>
  )
}
