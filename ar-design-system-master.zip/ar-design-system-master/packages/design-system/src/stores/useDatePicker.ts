import type {
  TStoreDatePicker,
  TStoreDatePickerData,
} from '@/stores/datePicker'

import { produce } from 'immer'
import { create } from 'zustand'

const defaltData = { datePicker: {} } satisfies TStoreDatePickerData

export const useDatePicker = create<TStoreDatePicker>((set) => ({
  data: defaltData,

  actions: {
    register: (name, mode) =>
      set((state) =>
        produce(state, (draft) => {
          if (state.data.datePicker[name]) return

          draft.data.datePicker[name] = {
            mode: mode || 'default',
          }
        }),
      ),
    setSelected: (name, selected) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data.datePicker[name]) return

          draft.data.datePicker[name].selected = selected
        }),
      ),
    setSubtextVariation: (name, subtextVariation) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data.datePicker[name]) return

          draft.data.datePicker[name].subtextVariation = subtextVariation
        }),
      ),
  },
}))
