import type { IIconLibLucideProps } from '~/@types/components/icons'

import { lucide } from './lucide'

export const lucideLib: IIconLibLucideProps = {
  title: 'Lucide Icons',
  icon: lucide.FileText,
  description:
    'Lucide contains icons with different variants and states, allowing users to choose the most suitable icon for their needs.\nIn addition to design, code is also important. Assets like icons can significantly increase bandwidth usage in web projects.\nLucide uses SVG compression and specific code architecture for tree-shaking abilities. After tree-shaking, you only ship the icons you used, which helps to keep software distribution size to a minimum.',
  icons: lucide,
}

export const iconLibs = {
  lucide: lucideLib,
} as const

export const iconsLucide = lucide
