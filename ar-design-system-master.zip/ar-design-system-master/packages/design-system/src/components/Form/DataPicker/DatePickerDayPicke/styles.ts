import { DayPicker as ReactDayPicker } from 'react-day-picker'

import { styled } from '~/styles'

export const DayPicker = styled(ReactDayPicker, {
  all: 'unset',
  display: 'flex',
  width: '$full',
  table: {
    all: 'unset',
    display: 'flex',
    flexDirection: 'column',
    width: '$full',
  },
  tbody: {
    all: 'unset',
    display: 'flex',
    flexDirection: 'column',
    width: '$full',
    borderRadius: '$rounded-md',
    overflow: 'hidden',
  },
})
