import type { TDataPickerHeaderWeekDayProps } from '@/components/form/dataPicker'

import { WEEK_DISPLAY_TYPE } from '_CST/datePicker'
import moment from 'moment/min/moment-with-locales'

import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { formatter } from '~/utils/formatter'

import { WeekDay } from './styles'

export function DataPickerHeaderWeekDay({
  weekday,
}: TDataPickerHeaderWeekDayProps) {
  const { locale, weekDisplay } = useDatePickerContext()

  const displayWeekDay = moment()
    .day(weekday)
    .locale(locale)
    .format(WEEK_DISPLAY_TYPE[weekDisplay])

  const labelWeekDay = moment().day(weekday).locale(locale).format('dddd')

  return (
    <WeekDay
      scope="col"
      data-element="data-picker-week-day"
      key={displayWeekDay}
      aria-label={labelWeekDay}
    >
      {formatter.string.name(displayWeekDay)}
    </WeekDay>
  )
}
