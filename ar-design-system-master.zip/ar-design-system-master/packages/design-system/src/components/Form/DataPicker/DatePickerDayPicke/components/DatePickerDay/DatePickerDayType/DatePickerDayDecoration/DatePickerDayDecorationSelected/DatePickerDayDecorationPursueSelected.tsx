import type { TDatePickerDayDecorationSelectedProps } from '@/components/form/dataPicker'

import { DaySelected } from './styles'

export function DatePickerDayDecorationPursueSelected(
  props: TDatePickerDayDecorationSelectedProps,
) {
  return (
    <DaySelected
      data-element="data-picker-decoration-pursue-selected"
      layoutId={`selected`}
      transition={{ duration: 0.15 }}
      highlight={props.highlight}
      rangeStart={props.rangeStart}
      rangeEnd={props.rangeEnd}
    />
  )
}
