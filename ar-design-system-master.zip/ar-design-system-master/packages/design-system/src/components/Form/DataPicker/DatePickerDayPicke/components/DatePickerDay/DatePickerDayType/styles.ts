import { styled } from '~/styles'

export const DaySimple = styled('div', {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  width: '$full',
  height: '$full',
  position: 'relative',
  '&[data-today="true"]::after': {
    content: '',
    borderWidth: '$border',
    borderStyle: '$solid',
    borderRadius: '$rounded-sm',
    borderColor: '$brand-primary-300',
    color: '$neutral-gray-50',
    width: '$full',
    height: '$full',
    position: 'absolute',
    zIndex: 1,
    transform: 'scale(0.90)',
  },
  '&[data-today="true"]::before': {
    content: '',
    position: 'absolute',
    width: '$full',
    height: '$full',
    left: 0,
    top: 0,
    background: '$brand-primary-300',
    transform: 'scale(0.90)',
    opacity: 0.1,
  },
  '&[data-range_middle="true"]': {
    background: '$brand-primary-300',
    borderColor: '$brand-primary',
    borderStyle: '$hidden',
    color: '$neutral-gray-50',
    '&[data-start_week="true"]': {
      borderTopLeftRadius: '$rounded-md',
      borderBottomLeftRadius: '$rounded-md',
    },
    '&[data-end_week="true"]': {
      borderTopRightRadius: '$rounded-md',
      borderBottomRightRadius: '$rounded-md',
    },
  },
})

export const DayButton = styled(DaySimple, {})

export const Day = styled('span', {
  textAlign: 'center',
  fontSize: '$sm',
  fontWeight: '$medium',
  color: '$neutral-gray-900',
  position: 'relatve',
  transition: 'color 150ms linear',
  zIndex: 4,
  variants: {
    active: {
      true: {
        color: '$neutral-gray-50',
      },
    },
  },
})
