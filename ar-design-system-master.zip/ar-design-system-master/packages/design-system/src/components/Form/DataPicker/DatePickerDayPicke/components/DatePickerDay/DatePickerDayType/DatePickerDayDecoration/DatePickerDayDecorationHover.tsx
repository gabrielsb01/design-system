import { DayHover } from './styles'

export function DatePickerDayDecorationHover() {
  return (
    <DayHover
      data-element="data-picker-decoration-hover"
      layoutId="day-hover"
      transition={{ duration: 0.1 }}
    />
  )
}
