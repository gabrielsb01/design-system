import { motion } from 'framer-motion'

import { styled } from '~/styles'

export const DaySelected = styled(motion.u, {
  borderRadius: '$rounded-sm',
  background: '$brand-primary',
  position: 'absolute',
  width: '$full',
  height: '$full',
  zIndex: 3,
  variants: {
    highlight: {
      true: {
        background: '$support-positive-400',
      },
    },
    rangeStart: {
      true: {
        borderBottomRightRadius: '$rounded-none',
        borderTopRightRadius: '$rounded-none',
      },
    },
    rangeEnd: {
      true: {
        borderBottomLeftRadius: '$rounded-none',
        borderTopLeftRadius: '$rounded-none',
      },
    },
  },
})
