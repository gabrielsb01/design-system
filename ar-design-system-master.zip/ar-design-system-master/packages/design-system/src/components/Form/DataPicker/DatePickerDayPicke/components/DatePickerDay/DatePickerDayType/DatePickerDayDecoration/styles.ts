import { motion } from 'framer-motion'

import { styled } from '~/styles'

export const Subtext = styled('em', {
  fontStyle: 'normal',
  fontSize: '$xxs',
  fontWeight: '$regular',
  color: '$neutral-gray-600',
  position: 'relative',
  zIndex: '4',
  '&[data-highlight="true"]': {
    fontWeight: '$medium',
    color: '$support-positive-600',
  },
  variants: {
    selected: {
      true: {
        color: '$neutral-gray-200',
        '&[data-highlight="true"]': {
          fontWeight: '$medium',
          color: '$neutral-gray-50',
        },
      },
    },
  },
})

export const DayHover = styled(motion.u, {
  borderWidth: '$border',
  borderStyle: '$solid',
  borderRadius: '$rounded-sm',
  borderColor: '$brand-secondary-300',
  width: '$full',
  height: '$full',
  position: 'absolute',
  overflow: 'hidden',
  zIndex: 2,
  '&:after': {
    content: '',
    position: 'absolute',
    width: '$full',
    height: '$full',
    left: 0,
    top: 0,
    background: '$brand-secondary-300',
    opacity: 0.1,
  },
})
