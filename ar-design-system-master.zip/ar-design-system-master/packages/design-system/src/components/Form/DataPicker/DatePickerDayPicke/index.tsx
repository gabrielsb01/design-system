import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { formatter } from '~/utils/formatter'

import { DatePickerDayPickeDefault } from './DatePickerDayPickeDefault'
import { DatePickerDayPickeMultiple } from './DatePickerDayPickeMultiple'
import { DatePickerDayPickeRange } from './DatePickerDayPickeRange'
import { DatePickerDayPickeSingle } from './DatePickerDayPickeSingle'

export function DatePickerDayPicke() {
  const contextProps = useDatePickerContext()
  const props = formatter.dataPicker.contextToDayPicker(contextProps)

  switch (props.mode) {
    case 'single':
      return <DatePickerDayPickeSingle {...props} />
    case 'range':
      return <DatePickerDayPickeRange {...props} />
    case 'multiple':
      return <DatePickerDayPickeMultiple {...props} />
    default:
      return <DatePickerDayPickeDefault {...props} />
  }
}
