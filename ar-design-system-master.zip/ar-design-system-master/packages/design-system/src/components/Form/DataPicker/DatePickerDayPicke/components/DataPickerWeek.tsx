import type { RowProps } from 'react-day-picker'

import { DatePickerDay } from './DatePickerDay'

import { Week } from './styles'

export type TDataPickerMonthsProps = RowProps

export function DataPickerWeek(props: TDataPickerMonthsProps) {
  return (
    <Week data-element="data-picker-week">
      {props.dates.map((date) => (
        <DatePickerDay
          key={date.toString()}
          date={date}
          displayMonth={props.displayMonth}
        />
      ))}
    </Week>
  )
}
