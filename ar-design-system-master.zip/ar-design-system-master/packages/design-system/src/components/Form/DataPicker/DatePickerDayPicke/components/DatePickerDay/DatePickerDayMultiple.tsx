import type {
  TDataPickerActiveModifiers,
  TDatePickerDayProps,
} from '@/components/form/dataPicker'

import { useActiveModifiers, useSelectMultiple } from 'react-day-picker'

import {
  DatePickerDayContentDefault,
  DatePickerDayContentDisabled,
  DatePickerDayContentHidden,
  DatePickerDayContentOutside,
} from './DatePickerDayContent'

export function DatePickerDayMultiple(props: TDatePickerDayProps) {
  const { onDayClick } = useSelectMultiple()
  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  if (modifiers.hidden) return <DatePickerDayContentHidden />
  if (modifiers.disabled) return <DatePickerDayContentDisabled {...props} />

  if (modifiers.outside) {
    return <DatePickerDayContentOutside {...props} onDayClick={onDayClick} />
  }

  return <DatePickerDayContentDefault {...props} onDayClick={onDayClick} />
}
