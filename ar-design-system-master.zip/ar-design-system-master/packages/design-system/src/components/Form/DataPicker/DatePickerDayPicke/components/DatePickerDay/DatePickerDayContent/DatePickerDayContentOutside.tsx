import type { TDatePickerDayContentProps } from '@/components/form/dataPicker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import {
  DatePickerDayContentSelectable,
  DatePickerDayTypeStatic,
} from '../DatePickerDayType'

import { Day } from './styles'

export function DatePickerDayContentOutside(props: TDatePickerDayContentProps) {
  const { selectableOutsideDays, outsideDays } = useDatePickerContext()

  if (!outsideDays)
    return (
      <Day role="presentation" data-element="data-picker-hidden-outside-day" />
    )

  return (
    <Day outside role="presentation" data-element="data-picker-outside-day">
      {selectableOutsideDays && <DatePickerDayContentSelectable {...props} />}
      {!selectableOutsideDays && <DatePickerDayTypeStatic {...props} />}
    </Day>
  )
}
