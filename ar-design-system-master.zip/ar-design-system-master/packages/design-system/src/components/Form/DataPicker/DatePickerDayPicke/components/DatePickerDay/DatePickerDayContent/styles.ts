import { styled } from '~/styles'

export const Day = styled('td', {
  all: 'unset',
  textAlign: 'center',
  fontSize: '$sm',
  fontWeight: '$medium',
  minWidth: '$12',
  height: '$12',
  flex: 1,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  variants: {
    disabled: {
      true: {
        opacity: 0.2,
        pointerEvents: 'none',
      },
    },
    outside: {
      true: {
        opacity: 0.4,
      },
    },
  },
})
