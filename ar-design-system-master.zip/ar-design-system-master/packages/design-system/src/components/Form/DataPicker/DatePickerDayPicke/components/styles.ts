import { styled } from '~/styles'

export const Container = styled('div', {
  all: 'unset',
  display: 'flex',
  flexDirection: 'column',
  gap: '$2',
  width: '$full',
  flex: 1,
})

export const Months = styled('div', {
  all: 'unset',
  display: 'flex',
  gap: '$10',
  width: '$full',
  flex: 1,
  flexWrap: 'wrap',
  '.month': {
    display: 'flex',
    width: '$full',
    flex: 1,
    flexDirection: 'column',
  },
})

export const Header = styled('div', {
  all: 'unset',
  display: 'flex',
  gap: '$2',
  alignItems: 'center',
})

export const Title = styled('span', {
  all: 'unset',
  flex: '1',
  fontWeight: '$bold',
  fontSize: '$medium',
  textAlign: 'center',
})

export const WeekHeader = styled('thead', {
  all: 'unset',
  display: 'flex',
  width: '$full',
  tr: {
    all: 'unset',
    display: 'flex',
    width: '$full',
  },
})
export const WeekDay = styled('td', {
  all: 'unset',
  textAlign: 'center',
  fontSize: '$xs',
  fontWeight: '$medium',
  flex: 1,
  minWidth: '$12',
  height: '$8',
})

export const Week = styled('tr', {
  all: 'unset',
  display: 'flex',
  width: '$full',
})

export const SelectVariant = styled('div', {
  all: 'unset',
  display: 'flex',
  width: '$full',
  alignItems: 'center',
  justifyItems: 'center',
  select: {
    maxWidth: '300px',
    width: '50%',
    margin: '0 auto',
  },
})
