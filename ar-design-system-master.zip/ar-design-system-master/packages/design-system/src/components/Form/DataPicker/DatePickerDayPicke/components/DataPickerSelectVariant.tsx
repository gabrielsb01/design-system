import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { useDatePicker } from '~/stores/useDatePicker'

import { SelectVariant } from './styles'

export function DataPickerSelectVariant() {
  const { name, subtextVariations } = useDatePickerContext()

  const setSubtextVariation =
    useDatePicker.getState().actions.setSubtextVariation

  if (!subtextVariations) return null

  return (
    <SelectVariant>
      <select
        onChange={(e) => {
          setSubtextVariation(name, e.target.value)
        }}
      >
        {Object.entries(subtextVariations).map(([key, value], i) => (
          <option value={key} key={key} selected={!i}>
            {value}
          </option>
        ))}
      </select>
    </SelectVariant>
  )
}
