import type { TDataPickerRangeDayPickerProps } from '@/components/form/dataPicker'

import { DateRange } from 'react-day-picker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { useDatePicker } from '~/stores/useDatePicker'

import { DataPickerContainer } from './components/DataPickerContainer'
import { DataPickerHeader } from './components/DataPickerHeader'
import { DataPickerHeaderWeek } from './components/DataPickerHeaderWeek'
import { DataPickerWeek } from './components/DataPickerWeek'

import { DayPicker } from './styles'

export function DatePickerDayPickeRange(props: TDataPickerRangeDayPickerProps) {
  const { name } = useDatePickerContext()

  const setSelected = useDatePicker((st) => st.actions.setSelected)
  const selected = useDatePicker((st) => st.data.datePicker[name].selected)

  return (
    <DayPicker
      {...props}
      data-element="date-picker-mode-range"
      selected={selected as DateRange}
      onSelect={(date?: DateRange) => setSelected(name, date)}
      components={{
        Months: DataPickerContainer,
        Caption: DataPickerHeader,
        Head: DataPickerHeaderWeek,
        Row: DataPickerWeek,
      }}
    />
  )
}
