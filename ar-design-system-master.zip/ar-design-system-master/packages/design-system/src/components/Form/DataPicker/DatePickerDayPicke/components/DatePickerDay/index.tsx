import { DayProps } from 'react-day-picker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import { DatePickerDayDefault } from './DatePickerDayDefault'
import { DatePickerDayMultiple } from './DatePickerDayMultiple'
import { DatePickerDayRange } from './DatePickerDayRange'
import { DatePickerDaySingle } from './DatePickerDaySingle'

export function DatePickerDay({ ...rest }: DayProps) {
  const { mode } = useDatePickerContext()

  switch (mode) {
    case 'single':
      return <DatePickerDaySingle {...rest} />
    case 'range':
      return <DatePickerDayRange {...rest} />
    case 'multiple':
      return <DatePickerDayMultiple {...rest} />
    default:
      return <DatePickerDayDefault {...rest} />
  }
}
