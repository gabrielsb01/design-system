import type { TDatePickerDayContentProps } from '@/components/form/dataPicker'

import { DatePickerDayContentSelectable } from '../DatePickerDayType'

import { Day } from './styles'

export function DatePickerDayContentDisabled(
  props: TDatePickerDayContentProps,
) {
  return (
    <Day disabled role="presentation" data-element="data-picker-disabled-day">
      <DatePickerDayContentSelectable {...props} />
    </Day>
  )
}
