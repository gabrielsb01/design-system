import type {
  TDataPickerActiveModifiers,
  TDatePickerDayProps,
} from '@/components/form/dataPicker'

import { useActiveModifiers, useSelectRange } from 'react-day-picker'

import {
  DatePickerDayContentDefault,
  DatePickerDayContentDisabled,
  DatePickerDayContentHidden,
  DatePickerDayContentOutside,
} from './DatePickerDayContent'

export function DatePickerDayRange(props: TDatePickerDayProps) {
  const { onDayClick } = useSelectRange()
  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  if (modifiers.hidden) return <DatePickerDayContentHidden />
  if (modifiers.outside) {
    return <DatePickerDayContentOutside {...props} onDayClick={onDayClick} />
  }

  if (modifiers.disabled) return <DatePickerDayContentDisabled {...props} />

  return <DatePickerDayContentDefault {...props} onDayClick={onDayClick} />
}
