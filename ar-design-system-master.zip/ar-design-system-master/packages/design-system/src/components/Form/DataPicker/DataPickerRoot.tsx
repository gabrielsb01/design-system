import type { TDatePickerRootProps } from '@/components/form/dataPicker'

import { DatePickerContextProvide } from '~/contexts/DatePickerContext'

import { DatePickerDayPicke } from './DatePickerDayPicke'

export function DataPickerRoot({
  locale = 'pt-br',
  outsideDays = false,
  weekDisplay = 'abbreviation',
  weekStartsOn = 0,
  numberOfMonths = 1,
  selectableOutsideDays = false,
  hidden,
  disabled,
  subtext,
  highlight,
  ...rest
}: TDatePickerRootProps) {
  return (
    <DatePickerContextProvide
      locale={locale}
      outsideDays={outsideDays}
      weekDisplay={weekDisplay}
      weekStartsOn={weekStartsOn}
      numberOfMonths={numberOfMonths}
      selectableOutsideDays={selectableOutsideDays}
      modifiers={{ hidden, disabled, subtext, highlight }}
      {...rest}
    >
      <DatePickerDayPicke />
    </DatePickerContextProvide>
  )
}
