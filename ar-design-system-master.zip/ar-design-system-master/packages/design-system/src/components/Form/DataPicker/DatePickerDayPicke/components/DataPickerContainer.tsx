import type { MonthsProps } from 'react-day-picker'

import { DataPickerSelectVariant } from './DataPickerSelectVariant'

import { Container, Months } from './styles'

export function DataPickerContainer({ children }: MonthsProps) {
  return (
    <Container>
      <DataPickerSelectVariant />
      <Months data-element="data-picker-months">{children}</Months>
    </Container>
  )
}
