import type {
  TDataPickerActiveModifiers,
  TDatePickerDayProps,
} from '@/components/form/dataPicker'

import { useActiveModifiers } from 'react-day-picker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { useDatePicker } from '~/stores/useDatePicker'

import { Subtext } from './styles'

export function DatePickerDayDecorationSubtext(props: TDatePickerDayProps) {
  const { name, getSubtext } = useDatePickerContext()

  const subtextVariation = useDatePicker(
    (st) => st.data.datePicker[name].subtextVariation,
  )

  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  if (!modifiers.subtext) return null

  const subtext = getSubtext(props.date, 'subtext', subtextVariation)

  return (
    <Subtext
      data-element="data-picker-decoration-subtext"
      data-highlight={modifiers.highlight}
      selected={modifiers.selected}
    >
      {subtext}
    </Subtext>
  )
}
