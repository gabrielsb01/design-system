import type { TDataPickerDefaultDayPickerProps } from '@/components/form/dataPicker'

import { DataPickerContainer } from './components/DataPickerContainer'
import { DataPickerHeader } from './components/DataPickerHeader'
import { DataPickerHeaderWeek } from './components/DataPickerHeaderWeek'
import { DataPickerWeek } from './components/DataPickerWeek'

import { DayPicker } from './styles'

export function DatePickerDayPickeDefault(
  props: TDataPickerDefaultDayPickerProps,
) {
  return (
    <DayPicker
      {...props}
      data-element="date-picker-mode-static"
      components={{
        Months: DataPickerContainer,
        Caption: DataPickerHeader,
        Head: DataPickerHeaderWeek,
        Row: DataPickerWeek,
      }}
    />
  )
}
