import type { TDatePickerDayContentProps } from '@/components/form/dataPicker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import {
  DatePickerDayContentSelectable,
  DatePickerDayContentSimple,
} from '../DatePickerDayType'

import { Day } from './styles'

export function DatePickerDayContentDefault(props: TDatePickerDayContentProps) {
  const { mode } = useDatePickerContext()
  const isCalendarMode = mode === 'default'

  return (
    <Day role="presentation" data-element="data-picker-day">
      {!isCalendarMode && <DatePickerDayContentSelectable {...props} />}
      {isCalendarMode && <DatePickerDayContentSimple {...props} />}
    </Day>
  )
}
