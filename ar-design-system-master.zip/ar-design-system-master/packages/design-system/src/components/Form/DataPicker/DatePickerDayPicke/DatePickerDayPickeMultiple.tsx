import type { TDataPickerMultipleDayPickerProps } from '@/components/form/dataPicker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { useDatePicker } from '~/stores/useDatePicker'

import { DataPickerContainer } from './components/DataPickerContainer'
import { DataPickerHeader } from './components/DataPickerHeader'
import { DataPickerHeaderWeek } from './components/DataPickerHeaderWeek'
import { DataPickerWeek } from './components/DataPickerWeek'

import { DayPicker } from './styles'

export function DatePickerDayPickeMultiple(
  props: TDataPickerMultipleDayPickerProps,
) {
  const { name } = useDatePickerContext()

  const setSelected = useDatePicker((st) => st.actions.setSelected)
  const selected = useDatePicker((st) => st.data.datePicker[name].selected)

  return (
    <DayPicker
      {...props}
      data-element="date-picker-mode-multiple"
      selected={selected as Date[]}
      onSelect={(date?: Date[]) => setSelected(name, date)}
      components={{
        Months: DataPickerContainer,
        Caption: DataPickerHeader,
        Head: DataPickerHeaderWeek,
        Row: DataPickerWeek,
      }}
    />
  )
}
