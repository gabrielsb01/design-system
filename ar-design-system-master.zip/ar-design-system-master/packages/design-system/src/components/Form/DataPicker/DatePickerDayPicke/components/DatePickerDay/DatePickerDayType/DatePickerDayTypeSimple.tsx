import type {
  TDataPickerActiveModifiers,
  TDatePickerDayContentProps,
} from '@/components/form/dataPicker'

import { useActiveModifiers } from 'react-day-picker'

import moment from 'moment/min/moment-with-locales'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import {
  DatePickerDayDecorationSelected,
  DatePickerDayDecorationSubtext,
} from './DatePickerDayDecoration'

import { Day, DaySimple } from './styles'

export function DatePickerDayContentSimple(props: TDatePickerDayContentProps) {
  const { locale } = useDatePickerContext()

  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  const day = moment(props.date).locale(locale).format('DD')

  return (
    <DaySimple
      data-element="data-picker-simple-day"
      data-today={modifiers.today}
      data-range_start={modifiers.range_start}
      data-range_middle={modifiers.range_middle}
      data-range_end={modifiers.range_end}
    >
      {modifiers.selected && <DatePickerDayDecorationSelected />}

      <Day active={modifiers.selected}>{day}</Day>

      <DatePickerDayDecorationSubtext {...props} />
    </DaySimple>
  )
}
