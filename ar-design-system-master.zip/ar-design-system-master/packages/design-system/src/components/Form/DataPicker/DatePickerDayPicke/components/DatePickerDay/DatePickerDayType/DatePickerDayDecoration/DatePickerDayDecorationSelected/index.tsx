import type { TDatePickerDayDecorationSelectedProps } from '@/components/form/dataPicker'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import { DatePickerDayDecorationExpandSelected } from './DatePickerDayDecorationExpandSelected'
import { DatePickerDayDecorationPursueSelected } from './DatePickerDayDecorationPursueSelected'

export function DatePickerDayDecorationSelected(
  props: TDatePickerDayDecorationSelectedProps,
) {
  const { mode } = useDatePickerContext()

  switch (mode) {
    case 'single':
      return <DatePickerDayDecorationPursueSelected {...props} />
    case 'range':
      return <DatePickerDayDecorationExpandSelected {...props} />
    case 'multiple':
      return <DatePickerDayDecorationPursueSelected {...props} />
    default:
      return <DatePickerDayDecorationExpandSelected {...props} />
  }
}
