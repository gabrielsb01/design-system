import type { CaptionProps } from 'react-day-picker'

import { useNavigation } from 'react-day-picker'

import { ArrowLeft, ArrowRight } from 'lucide-react'
import moment from 'moment/min/moment-with-locales'

import { Button } from '~/components/Form/Button'
import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { formatter } from '~/utils/formatter'

import { Header, Title } from './styles'

export type TDataPickerHeaderProps = CaptionProps

export function DataPickerHeader(props: TDataPickerHeaderProps) {
  const { locale, numberOfMonths } = useDatePickerContext()
  const { goToMonth, nextMonth, previousMonth } = useNavigation()

  const displayMonth = moment(props.displayMonth).locale(locale).format('MMMM')
  const displayYear = moment(props.displayMonth).locale(locale).format('yyyy')

  const showPrevius = props.displayIndex === 0
  const showNext = props.displayIndex === numberOfMonths - 1

  return (
    <Header data-element="data-picker-header">
      {showPrevius && (
        <Button
          name="left"
          size="medium"
          text
          data-element="data-picker-month-previous"
          disabled={!previousMonth}
          onClick={() => previousMonth && goToMonth(previousMonth)}
        >
          <ArrowLeft />
        </Button>
      )}
      <Title data-element="data-picker-month-title">
        {formatter.string.name(displayMonth)} {displayYear}
      </Title>
      {showNext && (
        <Button
          name="left"
          size="medium"
          text
          data-element="data-picker-month-next"
          disabled={!nextMonth}
          onClick={() => nextMonth && goToMonth(nextMonth)}
        >
          <ArrowRight />
        </Button>
      )}
    </Header>
  )
}
