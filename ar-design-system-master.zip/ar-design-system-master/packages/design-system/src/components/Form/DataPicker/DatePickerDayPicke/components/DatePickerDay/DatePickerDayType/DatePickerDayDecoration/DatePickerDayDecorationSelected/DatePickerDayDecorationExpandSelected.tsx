import type { TDatePickerDayDecorationSelectedProps } from '@/components/form/dataPicker'

import { DaySelected } from './styles'

export function DatePickerDayDecorationExpandSelected(
  props: TDatePickerDayDecorationSelectedProps,
) {
  return (
    <DaySelected
      data-element="data-picker-decoration-expand-selected"
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      transition={{
        duration: 0.15,
      }}
      highlight={props.highlight}
      rangeStart={props.rangeStart && !props.rangeEnd}
      rangeEnd={props.rangeEnd && !props.rangeStart}
    />
  )
}
