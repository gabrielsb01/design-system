import type {
  TDataPickerActiveModifiers,
  TDatePickerDayContentProps,
} from '@/components/form/dataPicker'

import { useState } from 'react'
import { useActiveModifiers } from 'react-day-picker'

import moment from 'moment/min/moment-with-locales'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import {
  DatePickerDayDecorationHover,
  DatePickerDayDecorationSelected,
  DatePickerDayDecorationSubtext,
} from './DatePickerDayDecoration'

import { Day, DayButton } from './styles'

export function DatePickerDayContentSelectable(
  props: TDatePickerDayContentProps,
) {
  const [hover, setHover] = useState(false)
  const { locale } = useDatePickerContext()

  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  const day = moment(props.date).locale(locale).format('DD')

  return (
    <DayButton
      as="button"
      type="button"
      data-element="data-picker-selectable-day"
      data-today={modifiers.today}
      data-range_middle={modifiers.range_middle}
      data-start_week={modifiers.start_week}
      data-end_week={modifiers.end_week}
      onMouseEnter={() => {
        setHover(true)
      }}
      onMouseLeave={() => {
        setHover(false)
      }}
      onClick={(e) => {
        if (!props.onDayClick) return
        props.onDayClick(props.date, modifiers, e)
      }}
    >
      {modifiers.selected && !modifiers.range_middle && (
        <DatePickerDayDecorationSelected
          highlight={modifiers.highlight}
          rangeStart={modifiers.range_start}
          rangeEnd={modifiers.range_end}
        />
      )}
      {hover && <DatePickerDayDecorationHover />}

      <Day active={modifiers.selected}>{day}</Day>

      <DatePickerDayDecorationSubtext {...props} />
    </DayButton>
  )
}
