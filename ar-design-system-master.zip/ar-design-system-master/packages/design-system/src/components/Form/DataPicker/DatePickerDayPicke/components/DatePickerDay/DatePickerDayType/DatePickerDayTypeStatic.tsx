import type {
  TDataPickerActiveModifiers,
  TDatePickerDayContentProps,
} from '@/components/form/dataPicker'

import { useActiveModifiers } from 'react-day-picker'

import moment from 'moment/min/moment-with-locales'

import { useDatePickerContext } from '~/contexts/DatePickerContext'

import {
  DatePickerDayDecorationSelected,
  DatePickerDayDecorationSubtext,
} from './DatePickerDayDecoration'

import { Day, DaySimple } from './styles'

export function DatePickerDayTypeStatic(props: TDatePickerDayContentProps) {
  const { locale } = useDatePickerContext()

  const modifiers = useActiveModifiers(
    props.date,
    props.displayMonth,
  ) as TDataPickerActiveModifiers

  const day = moment(props.date).locale(locale).format('DD')

  return (
    <DaySimple data-element="data-picker-static-day">
      {modifiers.selected && <DatePickerDayDecorationSelected />}

      <Day active={modifiers.selected}>{day}</Day>

      <DatePickerDayDecorationSubtext {...props} />
    </DaySimple>
  )
}
