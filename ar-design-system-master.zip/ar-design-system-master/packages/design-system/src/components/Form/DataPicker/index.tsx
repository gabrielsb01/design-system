import { DataPickerRoot } from './DataPickerRoot'

export const DataPicke = {
  Root: DataPickerRoot,
}
