import { useDatePickerContext } from '~/contexts/DatePickerContext'
import { getWeekdays } from '~/utils'

import { DataPickerHeaderWeekDay } from './DataPickerHeaderWeekDay'

import { WeekHeader } from './styles'

export function DataPickerHeaderWeek() {
  const { weekStartsOn } = useDatePickerContext()
  const weekdays = getWeekdays(weekStartsOn)
  return (
    <WeekHeader data-element="data-picker-week-header">
      <tr>
        {weekdays.map((weekday) => (
          <DataPickerHeaderWeekDay weekday={weekday} key={weekday} />
        ))}
      </tr>
    </WeekHeader>
  )
}
