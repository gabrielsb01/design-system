import { Day } from './styles'

export function DatePickerDayContentHidden() {
  return <Day role="presentation" data-element="data-picker-hidden-day" />
}
