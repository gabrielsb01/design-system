import type { ComponentProps } from 'react'

import { useRef, useState } from 'react'

import { generateTestIdKey } from '~/utils'

import { Container, HiddenElement } from './styles'

export type TRadioStatus = 'checked' | 'unchecked'

export interface IRadioProps extends ComponentProps<typeof Container> {
  name: string
  value: string
}

function getRadioStatusName(status: boolean) {
  if (status) return 'checked'
  return 'unchecked'
}

export function Radio({
  name,
  value,
  defaultValue,
  defaultChecked = false,
  ...rest
}: IRadioProps) {
  const [elementState, setElementState] = useState<TRadioStatus>(
    getRadioStatusName(defaultChecked),
  )
  const hiddenElementRef = useRef<HTMLInputElement>(null)

  const testId = generateTestIdKey('input', name)

  const toggleStatus = () => {
    if (!hiddenElementRef.current) return null
    const currentStatus = hiddenElementRef.current.checked
    const newElementState = getRadioStatusName(!currentStatus)

    hiddenElementRef.current.checked = !currentStatus
    setElementState(newElementState)
  }

  return (
    <>
      <Container
        {...rest}
        role="radio"
        aria-checked={!!hiddenElementRef.current?.checked}
        data-state={elementState}
        data-testid={testId}
        onClick={toggleStatus}
        aria-label={value}
      />
      <HiddenElement
        type="radio"
        aria-hidden="true"
        tabIndex={-1}
        value={value}
        defaultValue={defaultValue}
        ref={hiddenElementRef}
        checked={elementState === 'checked'}
      />
    </>
  )
}

Radio.displayName = 'Radio'
