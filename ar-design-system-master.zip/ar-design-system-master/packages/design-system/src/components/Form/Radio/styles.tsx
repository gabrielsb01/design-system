import { styled } from '~/styles'

export const Container = styled('button', {
  all: 'unset',
  borderWidth: '1px',
  borderStyle: '$solid',
  width: '$4',
  height: '$4',
  borderRadius: '$rounded-full',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  borderColor: 'CurrentColor',
  cursor: 'pointer',
  position: 'relative',
  '&::before': {
    all: 'unset',
    content: '',
    width: '0',
    height: '0',
    position: 'absolute',
    background: 'CurrentColor',
    borderRadius: '$rounded-full',
    transition: 'all 150ms cubic-bezier(0.53, 0.01, 0.64, 1.61)',
  },
  '&[data-state="checked"]': {
    '&::before': {
      width: '80%',
      height: '80%',
    },
  },
  '&:disabled': {
    opacity: 0.5,
    filter: 'grayscale(1)',
    pointerEvents: 'none',
  },

  variants: {
    variant: {
      primary: {
        color: '$brand-primary',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$brand-primary-300',
        },
      },
      secondary: {
        color: '$brand-secondary',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$brand-secondary-300',
        },
      },
      informative: {
        color: '$support-informative-500',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$support-informative-300',
        },
      },
      positive: {
        color: '$support-positive-500',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$support-positive-300',
        },
      },
      warning: {
        color: '$support-warning-500',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$support-warning-300',
        },
      },
      negative: {
        color: '$support-negative-500',
        '&:focus:not(:disabled)': {
          boxShadow: '0px 0px 0px 2px $colors$support-negative-300',
        },
      },
    },
  },
})

export const HiddenElement = styled('input', {
  translateX: '-100%',
  position: 'absolute',
  pointerEvents: 'none',
  opacity: 0,
  margin: '0px',
  width: '25px',
  height: '25px',
})
