import { motion } from 'framer-motion'

import { styled } from '~/styles'

export const SwitchRoot = styled('span', {
  all: 'unset',
  width: '$14',
  height: '$7',
  padding: '$1',
  display: 'flex',
  boxSizing: 'border-box',
  borderWidth: '$border',
  borderStyle: '$solid',
  color: '$brand-primary-600',
  borderColor: 'CurrentColor',
  borderRadius: '$rounded-full',
  alignItems: 'center',
  justifyContent: 'flex-start',
  backgroundColor: 'transparent',
  transition: 'background 500ms ease',
  cursor: 'pointer',
  variants: {
    variant: {
      primary: {
        color: '$brand-primary',
        button: {
          color: '$brand-primary-600',
          '&::before': {
            backgroundColor: '$brand-primary-700',
          },
        },
      },
      secondary: {
        color: '$brand-secondary',
        button: {
          color: '$brand-secondary-600',
          '&::before': {
            backgroundColor: '$brand-secondary-700',
          },
        },
      },
      informative: {
        color: '$support-informative-600',
        button: {
          color: '$support-informative-600',
          '&::before': {
            backgroundColor: '$support-informative-700',
          },
        },
      },
      positive: {
        color: '$support-positive-600',
        button: {
          color: '$support-positive-600',
          '&::before': {
            backgroundColor: '$support-positive-700',
          },
        },
      },
      warning: {
        color: '$support-warning-600',
        button: {
          color: '$support-warning-600',
          '&::before': {
            backgroundColor: '$support-warning-700',
          },
        },
      },
      negative: {
        color: '$support-negative-600',
        button: {
          color: '$support-negative-600',
          '&::before': {
            backgroundColor: '$support-negative-700',
          },
        },
      },
    },
    disabled: {
      true: {
        opacity: 0.5,
        filter: 'grayscale(1)',
        pointerEvents: 'none',
      },
      false: {
        'button:focus::before': {
          width: '$9',
          height: '$9',
        },
      },
    },
    active: {
      true: {
        justifyContent: 'flex-end',
        backgroundColor: 'CurrentColor',
        button: {
          width: '$5',
          height: '$5',
          color: '$neutral-gray-50',
          boxShadow: '$elevation-1',
        },
      },
    },
  },
  compoundVariants: [
    {
      variant: 'primary',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$brand-primary',
          },
        },
      },
    },
    {
      variant: 'secondary',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$brand-secondary',
          },
        },
      },
    },
    {
      variant: 'informative',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$support-informative-600',
          },
        },
      },
    },
    {
      variant: 'positive',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$support-positive-600',
          },
        },
      },
    },
    {
      variant: 'warning',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$support-warning-600',
          },
        },
      },
    },
    {
      variant: 'negative',
      active: true,
      css: {
        button: {
          color: '$neutral-gray-50',
          svg: {
            color: '$support-negative-600',
          },
        },
      },
    },
  ],
  defaultVariants: {
    active: false,
    variant: 'primary',
  },
})

export const SwitchButton = styled(motion.button, {
  all: 'unset',
  display: 'flex',
  width: '$4',
  height: '$4',
  background: 'CurrentColor',
  borderRadius: '$rounded-full',
  justifyContent: 'center',
  alignItems: 'center',
  padding: '0.125rem',
  boxSizing: 'border-box',
  position: 'relative',
  '&>svg': {
    color: '$neutral-gray-50',
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain',
    position: 'relative',
    zIndex: 3,
  },
  '&::after': {
    content: '',
    position: 'absolute',
    left: '50%',
    top: '50%',
    transform: 'translate(-50%,-50%)',
    background: 'CurrentColor',
    width: '100%',
    height: '100%',
    borderRadius: '$rounded-full',
    zIndex: 2,
  },
  '&::before': {
    content: '',
    position: 'absolute',
    left: '50%',
    top: '50%',
    transform: 'translate(-50%,-50%)',
    width: '0%',
    height: '0%',
    opacity: '.3',
    borderRadius: '$rounded-full',
    zIndex: 0,
    transition: 'all 150ms ease',
  },
})

export const HiddenElement = styled('input', {
  translateX: '-100%',
  position: 'absolute',
  pointerEvents: 'none',
  opacity: 0,
  margin: '0px',
  width: '25px',
  height: '25px',
})
