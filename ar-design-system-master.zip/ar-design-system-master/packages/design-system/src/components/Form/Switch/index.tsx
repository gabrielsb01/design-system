import type { ChangeEvent, ComponentProps, ReactNode } from 'react'

import { forwardRef, useRef, useState } from 'react'

import _ from 'lodash'

import { generateTestIdKey, mergeRefs } from '~/utils'

import { HiddenElement, SwitchButton, SwitchRoot } from './styles'

export type TSwitchStatus = 'checked' | 'unchecked'

type TSwitchRoot = ComponentProps<typeof SwitchRoot>
type TSwitchButton = ComponentProps<typeof SwitchButton>

type TSwitchVariants =
  | 'primary'
  | 'secondary'
  | 'informative'
  | 'positive'
  | 'warning'
  | 'negative'

export interface ISwitchProps extends Omit<TSwitchRoot, 'onChange'> {
  name: string
  value: readonly string[]
  rootCss?: Partial<TSwitchRoot['css']>
  buttonCss?: Partial<TSwitchButton['css']>
  icon?: ReactNode
  offIcon?: ReactNode
  onVariant?: TSwitchVariants
  offVariant?: TSwitchVariants
  onChange?: (value: string) => string
}

export const Switch = forwardRef<
  HTMLInputElement | null | undefined,
  ISwitchProps
>(
  (
    {
      name,
      icon,
      rootCss,
      offIcon,
      buttonCss,
      variant,
      onVariant,
      offVariant,
      onChange,
      value = ['off', 'on'],
      defaultChecked = false,
      ...rest
    },
    forwardedRef,
  ) => {
    const [isActive, setIsActive] = useState<boolean>(defaultChecked)
    const hiddenElementRef = useRef<HTMLInputElement | null>(null)

    const testId = generateTestIdKey('input', name)

    const valueIndex = _.toNumber(isActive)

    const stateVariant = isActive ? onVariant : offVariant
    const dynamicVariant =
      onVariant && offVariant ? { variant: stateVariant } : { variant }

    const activeIcon = icon
    const inactiveIcon = !_.isNull(offIcon) ? offIcon || icon : null

    const setHiddenElement = (status: boolean) => {
      if (!hiddenElementRef.current) return null
      hiddenElementRef.current.checked = status
    }

    const toggleActive = (status?: boolean) => {
      if (!hiddenElementRef.current) return null
      const currentHiddenElementStatus = hiddenElementRef.current.checked
      const newStatus = !!status || !isActive

      if (currentHiddenElementStatus !== newStatus) setHiddenElement(newStatus)

      setIsActive(newStatus)
      if (onChange) onChange(value[_.toNumber(newStatus)])
    }

    return (
      <>
        <SwitchRoot
          {...rest}
          {...dynamicVariant}
          css={rootCss}
          active={isActive}
          onClick={() => toggleActive()}
        >
          <SwitchButton
            layout
            role="checkbox"
            disabled={!!rest.disabled}
            css={buttonCss}
            aria-label={name}
            data-testid={testId}
            aria-checked={isActive}
            data-status={value[valueIndex]}
            transition={{ type: 'spring', stiffness: 700, damping: 30 }}
          >
            {isActive && activeIcon}
            {!isActive && inactiveIcon}
          </SwitchButton>
        </SwitchRoot>

        <HiddenElement
          type="checkbox"
          aria-hidden="true"
          tabIndex={-1}
          value={value[1]}
          disabled={!!rest.disabled}
          defaultChecked={defaultChecked}
          ref={mergeRefs(hiddenElementRef, forwardedRef)}
          onChange={(e: ChangeEvent<HTMLInputElement>) =>
            toggleActive(e.target.checked)
          }
        />
      </>
    )
  },
)

Switch.displayName = 'Switch'
