import type {
  ILucideIconProps,
  TLucideIcon,
  TLucideIconPosition,
} from '~/@types'
import type { ComponentProps, ReactNode } from 'react'

import { TextFieldProvider } from './CondextTextField'
import { TTextFieldInputProps } from './TextFieldInput'
import { useTextField } from './useTextField'

import { Container } from './styles'

export type TTextFieldProps = ComponentProps<typeof Container> & {
  name: string
  icon?: ILucideIconProps
}

export type TTextStoryProps = Omit<TTextFieldInputProps, 'label'> & {
  /** Name to identify and create test-id property */
  name: string
  /** Icons name of Lucide icons */
  iconName: TLucideIcon
  /** Position of icon inside the text field accepted 'start' | 'end'   */
  iconPosition: TLucideIconPosition
  /** Fixed label  */
  label?: ReactNode
  /** Placeholder Label  */
  placeholderLabel?: string
  /** Supporting text or ReactNode element */
  supporting?: ReactNode
}

export function TextFieldRoot({
  name,
  children,
  icon,
  ...rest
}: TTextFieldProps) {
  const register = useTextField((st) => st.actions.register)

  register(name, icon)

  return (
    <TextFieldProvider name={name}>
      <Container data-element="text-field-root" {...rest}>
        {children}
      </Container>
    </TextFieldProvider>
  )
}

TextFieldRoot.displayName = 'TextField'
