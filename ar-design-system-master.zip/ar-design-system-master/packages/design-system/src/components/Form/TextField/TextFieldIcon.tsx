import type { LucideProps } from 'lucide-react'

import { icons } from 'lucide-react'

import { useContext } from './CondextTextField'
import { useTextField } from './useTextField'

import { IconBox } from './styles'

export type TTextFieldIconProps = LucideProps

export function TextFieldIcon() {
  const { name } = useContext()
  const lucideIcon = useTextField((st) => st.data[name].icon)

  if (!lucideIcon) return null

  const LucideIcon = icons[lucideIcon.name]

  return (
    <IconBox data-element="icon-box" data-position={lucideIcon.position}>
      <LucideIcon data-element="icon" {...lucideIcon} />
    </IconBox>
  )
}

TextFieldIcon.displayName = 'TextField.Icon'
