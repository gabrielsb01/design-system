import type { ComponentProps } from 'react'

import { PlaceholderLabel } from './styles'

export type TTextFieldPlaceholderLabelProps = ComponentProps<
  typeof PlaceholderLabel
>

export function TextFieldPlaceholderLabel({
  children,
}: TTextFieldPlaceholderLabelProps) {
  return (
    <PlaceholderLabel data-element="placeholder-label">
      {children}
    </PlaceholderLabel>
  )
}

TextFieldPlaceholderLabel.displayName = 'TextField.PlaceholderLabel'
