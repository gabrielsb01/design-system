import type { ComponentProps } from 'react'

import { SupportingText } from './styles'

export type TTextFieldSupportingProps = ComponentProps<typeof SupportingText>

export function TextFieldSupporting({ children }: TTextFieldSupportingProps) {
  return (
    <SupportingText data-element="supporting-text">{children}</SupportingText>
  )
}

TextFieldSupporting.displayName = 'TextField.Supporting'
