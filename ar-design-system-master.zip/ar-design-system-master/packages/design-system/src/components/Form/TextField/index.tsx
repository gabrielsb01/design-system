import { TextFieldInput } from './TextFieldInput'
import { TextFieldLabel } from './TextFieldLabel'
import { TextFieldRoot } from './TextFieldRoot'
import { TextFieldSupporting } from './TextFieldSupporting'

export type * from './TextFieldInput'
export type * from './TextFieldLabel'
export type * from './TextFieldRoot'
export type * from './TextFieldSupporting'

export const TextField = {
  Root: TextFieldRoot,
  Input: TextFieldInput,
  Label: TextFieldLabel,
  Supporting: TextFieldSupporting,
}
