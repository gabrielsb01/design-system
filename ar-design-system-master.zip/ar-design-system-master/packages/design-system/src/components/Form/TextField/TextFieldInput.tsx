import type { ComponentProps } from 'react'

import { useContext } from './CondextTextField'
import { TextFieldIcon } from './TextFieldIcon'
import { TextFieldPlaceholderLabel } from './TextFieldPlaceholderLabel'
import { useTextField } from './useTextField'

import { Input, InputBox, TextFieldFieldset } from './styles'

export type TTextFieldInputProps = ComponentProps<typeof TextFieldFieldset> &
  Omit<ComponentProps<typeof Input>, 'name'> & {
    label?: string
  }

export function TextFieldInput({ label, css, ...rest }: TTextFieldInputProps) {
  const { name } = useContext()
  const setFocusedStatus = useTextField((st) => st.actions.setFocusedStatus)
  const setEmptyStatus = useTextField((st) => st.actions.setEmptyStatus)

  const icon = useTextField((st) => st.data[name].icon)

  return (
    <TextFieldFieldset css={css} data-element="fieldset">
      {!!icon && icon.position === 'start' && <TextFieldIcon />}
      {label && <legend data-element="label-space">{label}</legend>}
      <InputBox data-element="input-box">
        {label && (
          <TextFieldPlaceholderLabel>{label}</TextFieldPlaceholderLabel>
        )}
        <Input
          {...rest}
          name={name}
          role="input"
          data-element="input"
          data-status={rest.status}
          placeholder={rest.placeholder || ' '}
          onFocus={() => setFocusedStatus(name, true)}
          onBlur={() => setFocusedStatus(name, false)}
          onChange={(e) => setEmptyStatus(name, !e.target.value)}
        />
      </InputBox>
      {!!icon && icon.position === 'end' && <TextFieldIcon />}
    </TextFieldFieldset>
  )
}

TextFieldInput.displayName = 'TextField.Input'
