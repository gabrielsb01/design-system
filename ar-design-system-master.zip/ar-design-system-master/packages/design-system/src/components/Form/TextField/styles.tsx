import { styled } from '~/styles'

export const Container = styled('label', {
  all: 'unset',
  display: 'flex',
  flexDirection: 'column',
  gap: '$1',
  color: '$neutral-gray-500',

  '&:has(*[data-element="input"][data-status="primary"])': {
    color: '$brand-primary-600',
    '*[data-element="supporting-text"]': { color: '$brand-primary-600' },
  },
  '&:has(*[data-element="input"][data-status="secondary"])': {
    color: '$brand-secondary-600',
    '*[data-element="supporting-text"]': { color: '$brand-secondary-600' },
  },
  '&:has(*[data-element="input"][data-status="informative"])': {
    color: '$support-informative-600',
    '*[data-element="supporting-text"]': { color: '$support-informative-600' },
  },
  '&:has(*[data-element="input"][data-status="positive"])': {
    color: '$support-positive-600',
    '*[data-element="supporting-text"]': { color: '$support-positive-600' },
  },
  '&:has(*[data-element="input"][data-status="warning"])': {
    color: '$support-warning-600',
    '*[data-element="supporting-text"]': { color: '$support-warning-600' },
  },
  '&:has(*[data-element="input"][data-status="negative"])': {
    color: '$support-negative-600',
    '*[data-element="supporting-text"]': { color: '$support-negative-600' },
  },

  '&:has(*[data-element="input"]:disabled)': {
    opacity: 0.5,
    filter: 'grayscale(1)',
    pointerEvents: 'none',
  },
})

export const TextFieldFieldset = styled('fieldset', {
  all: 'unset',
  borderWidth: '$border',
  borderStyle: '$solid',
  borderColor: '$neutral-gray-500',
  width: '100%',
  height: '$12',
  borderRadius: '$rounded-sm',
  boxSizing: 'border-box',
  display: 'flex',
  position: 'relative',
  padding: '$3 $2',
  justifyContent: 'flex-start',
  alignItems: 'center',
  gap: '$2',
  transition: 'border-color 150ms linear',
  legend: {
    width: 'fit-content',
    height: '0px',
    fontSize: '0.75rem',
    overflowX: 'hidden',
    maxWidth: '100%',
    padding: '0',
    transition: 'all 150ms linear',
  },
  '&:has(*[data-element="input"][data-status="primary"])': {
    borderColor: '$brand-primary-600',
    '*[data-element="icon-box"]': {
      color: '$brand-primary-600',
    },
  },
  '&:has(*[data-element="input"][data-status="secondary"])': {
    borderColor: '$brand-secondary-600',
    '*[data-element="icon-box"]': {
      color: '$brand-secondary-600',
    },
  },
  '&:has(*[data-element="input"][data-status="informative"])': {
    borderColor: '$support-informative-600',
    '*[data-element="icon-box"]': {
      color: '$support-informative-600',
    },
  },
  '&:has(*[data-element="input"][data-status="positive"])': {
    borderColor: '$support-positive-600',
    '*[data-element="icon-box"]': {
      color: '$support-positive-600',
    },
  },
  '&:has(*[data-element="input"][data-status="warning"])': {
    borderColor: '$support-warning-600',
    '*[data-element="icon-box"]': {
      color: '$support-warning-600',
    },
  },
  '&:has(*[data-element="input"][data-status="negative"])': {
    borderColor: '$support-negative-600',
    '*[data-element="icon-box"]': {
      color: '$support-negative-600',
    },
  },
  '&:has(*[data-element="input"]:placeholder-shown)': {
    '*[data-element="placeholder-label"]': {
      fontSize: '1rem',
      color: '$neutral-gray-400',
      top: '0',
    },
    legend: {
      maxWidth: '0',
    },
  },
  '&:has(*[data-element="input"]:focus)': {
    '*[data-element="placeholder-label"]': {
      fontSize: '0.75rem',
      top: '-$6',
    },
    legend: {
      maxWidth: '100%',
    },
  },

  '&:has(*[data-element="icon-box"][data-position="start"])': {
    legend: {
      marginLeft: '$8',
    },
  },
})

export const PlaceholderLabel = styled('span', {
  position: 'absolute',
  boxSizing: 'border-box',
  padding: '0 $2 0 $4',
  fontSize: '0.75rem',
  top: '-$6',
  left: '-$2',
  transition: 'all 150ms linear',
})

export const Label = styled('span', {
  all: 'unset',
  boxSizing: 'border-box',
  color: '$neutral-gray-900',
  fontSize: '0.875rem',
})

export const InputBox = styled('div', {
  all: 'unset',
  minHeight: '100%',
  flex: 1,
  display: 'flex',
  position: 'relative',
  alignItems: 'center',
})

export const Input = styled('input', {
  all: 'unset',
  minHeight: '100%',
  with: '100%',
  fontSize: '1rem',
  display: 'flex',
  flex: 1,
  color: '$neutral-gray-500',
  position: 'relative',
  padding: '0 $2',
  '&:disabled': {
    pointerEvents: 'none',
  },

  '&::placeholder': {
    color: '$neutral-gray-400',
    userSelect: 'none',
  },
  variants: {
    status: {
      default: {},
      primary: {},
      secondary: {},
      informative: {},
      positive: {},
      warning: {},
      negative: {},
    },
  },
})

export const IconBox = styled('span', {
  all: 'unset',
  color: '$neutral-gray-600',
  transition: 'color 150ms linear',
})

export const SupportingText = styled('u', {
  all: 'unset',
  fontSize: '14px',
  color: '$neutral-gray-400',
  transition: 'color 150ms linear',
})
