import type {
  ITextFieldContextProps,
  ITextFieldProviderProps,
} from '~/@types/components/form/context/textField'

import { createContext, useContext as useTextFieldContext } from 'react'

const TextFieldContext = createContext({} as ITextFieldContextProps)

function TextFieldProvider({ children, ...rest }: ITextFieldProviderProps) {
  return (
    <TextFieldContext.Provider value={rest}>
      {children}
    </TextFieldContext.Provider>
  )
}

function useContext() {
  const context = useTextFieldContext(TextFieldContext)
  if (!context) {
    throw new Error(
      'TextField: useContext must be used within a TextFieldProvider',
    )
  }
  return context
}

export { useContext, TextFieldProvider }
