import type { ITextFieldStore } from '~/@types'

import { produce } from 'immer'
import _ from 'lodash'
import { create } from 'zustand'

export const useTextField = create<ITextFieldStore>((set) => ({
  data: {},
  actions: {
    register: (name, iconProps) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data[name]) {
            draft.data[name] = {
              empty: true,
              focused: false,
            }
          }

          if (!iconProps && state.data[name]?.icon) delete draft.data[name].icon
          if (!iconProps) return

          if (!state.data[name]?.icon) {
            draft.data[name].icon = {
              ...iconProps,
              name: iconProps.name,
              position: iconProps.position || 'start',
            }
            return
          }

          if (_.isEqual(iconProps, state.data[name].icon)) return
          draft.data[name].icon = {
            ...state.data[name].icon,
            ...iconProps,
          }
        }),
      ),
    update: (name, iconProps) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data[name]) return
          if (_.isEqual(iconProps, state.data[name].icon)) return

          console.log(iconProps)
          if (iconProps) {
            draft.data[name].icon = {
              ...iconProps,
              ...state.data[name].icon,
            }
          }
        }),
      ),
    setFocusedStatus: (name, status = false) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data[name]) return
          draft.data[name].focused = status
        }),
      ),
    setEmptyStatus: (name, status = false) =>
      set((state) =>
        produce(state, (draft) => {
          if (!state.data[name]) return
          if (status === state.data[name].empty) return

          draft.data[name].empty = status
        }),
      ),
  },
}))
