import type { ComponentProps } from 'react'

import { Label } from './styles'

export type TTextFieldLabelProps = ComponentProps<typeof Label>

export function TextFieldLabel({ children, ...rest }: TTextFieldLabelProps) {
  return (
    <Label {...rest} data-element="label">
      {children}
    </Label>
  )
}

TextFieldLabel.displayName = 'TextField.Label'
