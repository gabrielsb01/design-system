import { styled } from '~/styles'

export const Container = styled('button', {
  borderRadius: '8px',
  transition: 'all 150ms linear',
  fontSize: '1rem',
  gap: '$2',
  border: '1px solid transparent',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  cursor: 'pointer',
  fontWeight: 'bold',
  width: 'fit-content',
  height: 'fit-content',
  boxShadow: '$elevation-3',
  '&:not(:disabled):hover': {
    transform: 'scale(1.05)',
    boxShadow: '$elevation-6',
  },
  '&:not(:disabled):active': {
    transition: 'all 100ms linear',
    transform: 'scale(0.95)',
    boxShadow: '$elevation-1',
  },
  '&:disabled': {
    opacity: 0.5,
    filter: 'grayscale(1)',
    pointerEvents: 'none',
  },
  variants: {
    variant: {
      primary: {
        backgroundColor: '$brand-primary',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$brand-primary-800',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$brand-primary-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$brand-primary-300',
          transform: 'scale(1.05)',
        },
      },
      secondary: {
        backgroundColor: '$brand-secondary',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$brand-secondary-800',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$brand-secondary-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$brand-secondary-300',
          transform: 'scale(1.05)',
        },
      },
      informative: {
        backgroundColor: '$support-informative-500',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$support-informative-800 ',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$support-informative-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$support-informative-300',
          transform: 'scale(1.05)',
        },
      },
      positive: {
        backgroundColor: '$support-positive-500',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$support-positive-800',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$support-positive-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$support-positive-300',
          transform: 'scale(1.05)',
        },
      },
      warning: {
        backgroundColor: '$support-warning-500',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$support-warning-800',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$support-warning-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$support-warning-300',
          transform: 'scale(1.05)',
        },
      },
      negative: {
        backgroundColor: '$support-negative-500',
        color: '$neutral-gray-50',
        '&:not(:disabled):hover': {
          background: '$support-negative-800',
          color: '$neutral-gray-50',
        },
        '&:not(:disabled):active': {
          background: '$support-negative-900',
        },
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: '0px 0px 0px 3px $colors$support-negative-300',
          transform: 'scale(1.05)',
        },
      },
    },
    outline: {
      true: {
        backgroundColor: '$neutral-background-50',
      },
    },
    text: {
      true: {
        borderColor: 'transparent',
        backgroundColor: 'transparent',
        boxShadow: '$elevation-0',
        '&:focus:not(:disabled):not(:active):not(:hover)': {
          boxShadow: 'none',
          transform: 'scale(1.05)',
        },
      },
    },
    size: {
      small: {
        padding: '$1 $4',
      },
      medium: {
        padding: '$3 $4',
      },
      large: {
        padding: '$4',
      },
    },
  },
  compoundVariants: [
    {
      variant: 'primary',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$brand-primary',
        color: '$brand-primary',
      },
    },
    {
      variant: 'secondary',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$brand-secondary',
        color: '$brand-secondary',
      },
    },
    {
      variant: 'informative',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$support-informative-500',
        color: '$support-informative-500',
      },
    },
    {
      variant: 'positive',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$support-positive-500',
        color: '$support-positive-500',
      },
    },
    {
      variant: 'warning',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$support-warning-500',
        color: '$support-warning-500',
      },
    },
    {
      variant: 'negative',
      outline: true,
      css: {
        backgroundColor: '$neutral-background-50',
        borderColor: '$support-negative-500',
        color: '$support-negative-500',
      },
    },
    {
      variant: 'primary',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$brand-primary',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-50',
        },
      },
    },
    {
      variant: 'secondary',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$brand-secondary',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-50',
        },
      },
    },
    {
      variant: 'informative',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$support-informative-500',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-50',
        },
      },
    },
    {
      variant: 'positive',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$support-positive-500',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-50',
        },
      },
    },
    {
      variant: 'warning',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$support-warning-500',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-800',
        },
      },
    },
    {
      variant: 'negative',
      text: true,
      css: {
        backgroundColor: 'transparent',
        color: '$support-negative-500',
        '&:not(:disabled):hover': {
          color: '$neutral-gray-50',
        },
      },
    },
  ],
  defaultVariants: {
    size: 'medium',
    variant: 'primary',
  },
})
