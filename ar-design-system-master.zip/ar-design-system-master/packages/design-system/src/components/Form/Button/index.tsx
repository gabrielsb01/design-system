import type { ComponentProps } from 'react'

import { generateTestIdKey } from '~/utils'

import { Container } from './styles'

export interface IButtonProps extends ComponentProps<typeof Container> {
  name: string
}

export function Button({ name, ...rest }: IButtonProps) {
  const testId = generateTestIdKey('button', name)

  return <Container {...rest} data-testid={testId} />
}

Button.displayName = 'Button'
