import type { ComponentProps } from 'react'

import { useRef, useState } from 'react'

import { Check, Minus } from 'lucide-react'

import { generateTestIdKey } from '~/utils'

import { Container, HiddenElement } from './styles'

export type TCheckboxStatus = 'checked' | 'unchecked' | 'indeterminate'
export interface ICheckboxProps extends ComponentProps<typeof Container> {
  name: string
  indeterminate?: boolean
}

function getCheckboxStatusName(status: boolean) {
  if (status) return 'checked'
  return 'unchecked'
}

export function Checkbox({
  css,
  name,
  value,
  defaultChecked = false,
  indeterminate = false,
  ...rest
}: ICheckboxProps) {
  const [elementState, setElementState] = useState<TCheckboxStatus>(
    getCheckboxStatusName(defaultChecked),
  )
  const hiddenElementRef = useRef<HTMLInputElement>(null)
  const testId = generateTestIdKey('input', name)

  const isChecked = elementState === 'checked'

  if (hiddenElementRef.current) {
    hiddenElementRef.current.indeterminate = indeterminate
  }

  const toggleStatus = () => {
    if (!hiddenElementRef.current) return null
    const currentStatus = hiddenElementRef.current.checked
    const newElementState = getCheckboxStatusName(!currentStatus)

    hiddenElementRef.current.checked = !currentStatus
    setElementState(newElementState)
  }

  return (
    <>
      <Container
        {...rest}
        role="checkbox"
        css={css}
        aria-label={name}
        data-testid={testId}
        onClick={toggleStatus}
        aria-checked={isChecked}
        data-state={elementState}
      >
        {!!elementState && !indeterminate && <Check />}
        {!!indeterminate && <Minus />}
      </Container>
      <HiddenElement
        type="checkbox"
        aria-hidden="true"
        value={value}
        tabIndex={-1}
        checked={isChecked}
        ref={hiddenElementRef}
        defaultChecked={defaultChecked}
      />
    </>
  )
}

Checkbox.displayName = 'Checkbox'
