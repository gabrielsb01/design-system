import { ComponentProps } from 'react'

import { toast as sonnerToast, Toaster as Sonner } from 'sonner'

import { Toast } from './Toast'

export type ToasterProps = ComponentProps<typeof Sonner>
export type TToast = typeof sonnerToast

export const toast = {
  message: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="default"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  primary: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="primary"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  secondary: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="secondary"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  informative: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="informative"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  positive: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="positive"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  warning: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="warning"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
  negative: (message: string) =>
    sonnerToast.custom((t) => (
      <Toast
        type="negative"
        message={message}
        close={() => sonnerToast.dismiss(t)}
      />
    )),
}

export function Toaster({ ...rest }: ToasterProps) {
  return <Sonner {...rest} />
}

Toaster.displayName = 'Toaster'
