import { ComponentProps } from 'react'

import { Info, X } from 'lucide-react'

import { Container, Dismiss, Header, HeaderIcon, Title } from './styles'

export interface IToastProps extends ComponentProps<typeof Container> {
  message: string
  close: () => void
}

export function Toast({ message, close, ...rest }: IToastProps) {
  return (
    <Container {...rest}>
      <Header>
        <HeaderIcon>
          <Info />
        </HeaderIcon>
        <Title>{message}</Title>
        <Dismiss onClick={close}>
          <X />
        </Dismiss>
      </Header>
    </Container>
  )
}
