import { styled } from '~/styles'

export const Container = styled('div', {
  background: '$neutral-gray-50',
  height: 48,
  width: '350px',

  borderRadius: '$rounded-sm',
  padding: '$3 $4',
  color: '$neutral-gray-900',
  boxShadow: '$elevation-8',
  variants: {
    type: {
      default: {
        color: '$neutral-gray-900',
        background: '$neutral-gray-50',
      },
      primary: {
        color: '$neutral-gray-50',
        background: '$brand-primary-700',
      },
      secondary: {
        color: '$neutral-gray-50',
        background: '$brand-secondary-700',
      },
      informative: {
        color: '$neutral-gray-50',
        background: '$support-informative-700',
      },
      positive: {
        color: '$neutral-gray-50',
        background: '$support-positive-700',
      },
      warning: {
        color: '$neutral-gray-50',
        background: '$support-warning-700',
      },
      negative: {
        color: '$neutral-gray-50',
        background: '$support-negative-700',
      },
    },
  },
})

export const Header = styled('div', {
  display: 'flex',
  flexDirection: 'row',
  gap: '$2',
})

export const HeaderIcon = styled('div', {})
export const Title = styled('p', {
  flex: 1,
})
export const Dismiss = styled('button', {})
