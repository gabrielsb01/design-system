import type { TTagName } from '~/@types/globals'
import type { TRef } from '~/@types/utils/functions'

import { TDataPickerWeekNumber } from '@/components/form/dataPicker'

import { MutableRefObject } from 'react'

import _ from 'lodash'

import { TAG_SEQUENTIAL, TAG_TEST_ID_SUFFIX } from '~/constants/qa'

import { UniquePageId } from './builder'

export function generateTestIdKey(tag: TTagName, name?: string) {
  const pageID = UniquePageId({ type: 'number' })

  const tagName = name
  const tagPrefix = TAG_TEST_ID_SUFFIX[tag]
  const isSequential = _.includes(TAG_SEQUENTIAL, tag)
  const suffix = isSequential ? pageID.newId(`${tagPrefix}_`) : tagPrefix

  const testIdSlices = []

  testIdSlices.push(tagName)
  testIdSlices.push(suffix)

  return testIdSlices.join('')
}

export function mergeRefs<T>(...refs: TRef<T>[]): (instance: T | null) => void {
  return (instance) => {
    refs.forEach((ref) => {
      if (typeof ref === 'function') {
        ref(instance)
      } else if (ref !== null && typeof ref === 'object') {
        ;(ref as MutableRefObject<T | null>).current = instance
      }
    })
  }
}

export function getWeekdays(startsAt: TDataPickerWeekNumber) {
  return Array.from(
    { length: 7 },
    (_, i) => (startsAt + i) % 7,
  ) as TDataPickerWeekNumber[]
}
