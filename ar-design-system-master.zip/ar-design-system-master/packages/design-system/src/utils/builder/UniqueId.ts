import type {
  IUniqueIdBuilder,
  IUniqueIdProps,
  TIdTypes,
  TList,
} from '~/@types/builder/uniqueId'

import { createId } from '@paralleldrive/cuid2'
import _ from 'lodash'

export default class UniqueIdBuilder implements IUniqueIdBuilder {
  private readonly _type: TIdTypes = 'number'
  private _list: TList

  constructor(props: IUniqueIdProps) {
    this._type = props.type || this._type
    this._list = []
  }

  private generateNumber = (prefix?: string) => {
    const lastID = _.last(this._list) || '0'
    const numberID = +lastID
    const newID = `${prefix}${numberID + 1}`

    this._list.push(newID)

    return newID
  }

  private generateString = (prefix?: string) => {
    const newID = `${prefix}${createId()}`

    this._list.push(newID)
    return newID
  }

  private generate = (prefix?: string) => {
    switch (this._type) {
      case 'number':
        return this.generateNumber(prefix)
      case 'string':
        return this.generateString(prefix)
    }
  }

  public newId(prefix?: string) {
    return this.generate(prefix)
  }
}
