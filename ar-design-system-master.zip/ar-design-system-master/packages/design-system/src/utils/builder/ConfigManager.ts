import { createStitches, defaultThemeMap } from '@stitches/react'
import _ from 'lodash'

import { AConfigManagerBuilder } from '~/@types/abstracts/builder/configManager'
import { IConfig } from '~/@types/builder/configManager'
import { DEFAULT_CONFIG } from '~/constants/config'

export default class ConfigManagerBuilder extends AConfigManagerBuilder {
  static config = DEFAULT_CONFIG

  static get theme() {
    return ConfigManagerBuilder.config.theme
  }

  static setConfig(customConfig: Partial<IConfig>) {
    ConfigManagerBuilder.config = _.merge({}, DEFAULT_CONFIG, customConfig)

    createStitches({
      themeMap: {
        ...defaultThemeMap,
        width: 'space',
        height: 'space',
      },
      theme: ConfigManagerBuilder.theme,
    })
  }
}
