import type {
  IUniqueIdBuilder,
  IUniqueIdProps,
} from '~/@types/builder/uniqueId'

import slugify from 'slugify'

import ConfigManagerClass from './ConfigManager'
import UniqueIdClass from './UniqueId'

const BUniqueId: Record<string, IUniqueIdBuilder> = {}

export function UniquePageId(props: IUniqueIdProps) {
  const currentPage = window ? window.location.href : ''
  const pageHash = slugify(currentPage)

  if (BUniqueId[pageHash]) {
    return BUniqueId[pageHash]
  }

  BUniqueId[pageHash] = new UniqueIdClass(props)

  return BUniqueId[pageHash]
}

export function ConfigManager() {
  return ConfigManagerClass
}
