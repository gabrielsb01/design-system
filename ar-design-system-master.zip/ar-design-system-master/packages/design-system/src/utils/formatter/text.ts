export function name(str: string) {
  const arr = str.toLowerCase().split(' ')
  return arr
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ')
    .trim()
}
