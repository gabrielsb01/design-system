import type {
  TDataPickerModifier,
  TDataPickerPublicModifier,
  TDataPickerRawModifier,
  TDatePickerDayPickeProps,
  TEDataPickerLocale,
} from '@/components/form/dataPicker'

import { ZEDataPickerCustomModifier } from '@/components/form/dataPicker'
import { TDatePickerContextProps } from '@/contexts/datePickerContext'

import { DEFAULT_CLASS } from '_CST/datePicker'
import moment from 'moment/min/moment-with-locales'

import { modifiersFormatter } from './modifiersFormatter'

export function rawModifiers(
  rawModifiers: TDataPickerRawModifier,
  locale: TEDataPickerLocale,
) {
  const modifiers = {} as TDataPickerModifier
  const customModifier = {} as TDataPickerModifier

  Object.entries(rawModifiers).forEach(([key, value]) => {
    const modifierKey = key as TDataPickerPublicModifier
    const modifierValue = value

    if (ZEDataPickerCustomModifier.safeParse(modifierKey).success) {
      customModifier[modifierKey] = modifiersFormatter(modifierValue, locale)
      return
    }
    modifiers[modifierKey] = modifiersFormatter(modifierValue, locale)
  })

  return { modifiers, customModifier }
}

export function contextToDayPicker(
  props: TDatePickerContextProps,
): TDatePickerDayPickeProps {
  const toDate = (date?: string) =>
    date ? moment(date).locale(props.locale).toDate() : undefined

  const formattedModifiers = rawModifiers(props.modifiers, props.locale)

  const base = {
    mode: props.mode,

    today: toDate(props.today) || moment().locale(props.locale).toDate(),
    month: toDate(props.month),

    fromDate: toDate(props.fromDate),
    toDate: toDate(props.toDate),

    fromMonth: toDate(props.fromMonth),
    toMonth: toDate(props.toMonth),

    fromYear: props.fromYear,
    toYear: props.toYear,

    showOutsideDays: props.outsideDays,

    defaultMonth: toDate(props.defaultMonth),
    numberOfMonths: props.numberOfMonths,

    weekDisplay: props.weekDisplay,
    weekStartsOn: props.weekStartsOn,

    disabled: formattedModifiers.modifiers?.disabled,
    hidden: formattedModifiers.modifiers?.hidden,
    modifiers: {
      ...formattedModifiers.customModifier,
      start_week: {
        dayOfWeek: [0],
      },
      end_week: {
        dayOfWeek: [6],
      },
    },
    classNames: DEFAULT_CLASS,
  }

  switch (props.mode) {
    case 'single':
      return {
        ...base,
        required: props.required,
      }
    case 'range':
      return {
        ...base,
        min: props.min,
        max: props.min,
      }
    case 'multiple':
      return {
        ...base,
        min: props.min,
        max: props.min,
      }
    default:
      return {
        ...base,
      }
  }
}
