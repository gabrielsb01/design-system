import type {
  TDataPickerMecherRawModifier,
  TDataPickerMecherRawModifierDate,
  TDataPickerMecherRawModifierDateAfter,
  TDataPickerMecherRawModifierDateArray,
  TDataPickerMecherRawModifierDateBefore,
  TDataPickerMecherRawModifierDateInterval,
  TDataPickerMecherRawModifierDateRange,
  TDataPickerMecherRawModifierDateWithSubtext,
  TDataPickerMecherRawModifierDateWithSubtextArray,
  TDataPickerMecherRawModifierDayOfWeek,
  TEDataPickerLocale,
} from '@/components/form/dataPicker'

import {
  ZDataPickerMecherRawModifierDate,
  ZDataPickerMecherRawModifierDateAfter,
  ZDataPickerMecherRawModifierDateArray,
  ZDataPickerMecherRawModifierDateBefore,
  ZDataPickerMecherRawModifierDateInterval,
  ZDataPickerMecherRawModifierDateRange,
  ZDataPickerMecherRawModifierDateWithSubtext,
  ZDataPickerMecherRawModifierDateWithSubtextArray,
  ZDataPickerMecherRawModifierDayOfWeek,
} from '@/components/form/dataPicker'

import moment from 'moment/min/moment-with-locales'

type simpleDataType = {
  type: 'simple'
  data: TDataPickerMecherRawModifierDate
}
type arrayDataType = {
  type: 'array'
  data: TDataPickerMecherRawModifierDateArray
}
type rangeDataType = {
  type: 'range'
  data: TDataPickerMecherRawModifierDateRange
}
type beforeDataType = {
  type: 'before'
  data: TDataPickerMecherRawModifierDateBefore
}
type afterDataType = {
  type: 'after'
  data: TDataPickerMecherRawModifierDateAfter
}
type intervalDataType = {
  type: 'interval'
  data: TDataPickerMecherRawModifierDateInterval
}
type dayOfWeekDataType = {
  type: 'dayOfWeek'
  data: TDataPickerMecherRawModifierDayOfWeek
}
type withSubtextDataType = {
  type: 'withSubtext'
  data: TDataPickerMecherRawModifierDateWithSubtext
}
type withSubtextArrayDataType = {
  type: 'withSubtextArray'
  data: TDataPickerMecherRawModifierDateWithSubtextArray
}
type notFaoundType = {
  type: 'not-found'
}

function dataType(modifierValue: Partial<TDataPickerMecherRawModifier>) {
  const dateMecher = ZDataPickerMecherRawModifierDate.safeParse(modifierValue)
  if (dateMecher.success)
    return { type: 'simple', data: dateMecher.data } as simpleDataType

  const arrayMecher =
    ZDataPickerMecherRawModifierDateArray.safeParse(modifierValue)
  if (arrayMecher.success)
    return { type: 'array', data: arrayMecher.data } as arrayDataType

  const rangeMecher =
    ZDataPickerMecherRawModifierDateRange.safeParse(modifierValue)
  if (rangeMecher.success)
    return { type: 'range', data: rangeMecher.data } as rangeDataType

  const beforeMecher =
    ZDataPickerMecherRawModifierDateBefore.safeParse(modifierValue)

  if (beforeMecher.success)
    return { type: 'before', data: beforeMecher.data } as beforeDataType

  const afterMecher =
    ZDataPickerMecherRawModifierDateAfter.safeParse(modifierValue)
  if (afterMecher.success)
    return { type: 'after', data: afterMecher.data } as afterDataType

  const intervalMecher =
    ZDataPickerMecherRawModifierDateInterval.safeParse(modifierValue)
  if (intervalMecher.success)
    return { type: 'interval', data: intervalMecher.data } as intervalDataType

  const dayOfWeekMecher =
    ZDataPickerMecherRawModifierDayOfWeek.safeParse(modifierValue)
  if (dayOfWeekMecher.success)
    return {
      type: 'dayOfWeek',
      data: dayOfWeekMecher.data,
    } as dayOfWeekDataType

  const withSubtextMecher =
    ZDataPickerMecherRawModifierDateWithSubtext.safeParse(modifierValue)
  if (withSubtextMecher.success)
    return {
      type: 'withSubtext',
      data: withSubtextMecher.data,
    } as withSubtextDataType

  const withSubtextArrayMecher =
    ZDataPickerMecherRawModifierDateWithSubtextArray.safeParse(modifierValue)
  if (withSubtextArrayMecher.success)
    return {
      type: 'withSubtextArray',
      data: withSubtextArrayMecher.data,
    } as withSubtextArrayDataType

  return { type: 'not-found' } as notFaoundType
}

function formatDate(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDate,
) {
  return moment(date).locale(locale).toDate()
}

function formatDateArray(
  locale: TEDataPickerLocale,
  dates: TDataPickerMecherRawModifierDateArray,
) {
  return dates.map((date) => moment(date).locale(locale).toDate())
}

function formatDateRange(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDateRange,
) {
  return {
    from: moment(date.from).locale(locale).toDate(),
    to: moment(date.to).locale(locale).toDate(),
  }
}
function formatDateInterval(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDateInterval,
) {
  return {
    before: moment(date.before).locale(locale).toDate(),
    after: moment(date.after).locale(locale).toDate(),
  }
}
function formatDateBefore(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDateBefore,
) {
  return {
    before: moment(date.before).locale(locale).toDate(),
  }
}
function formatDateAfter(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDateAfter,
) {
  return {
    after: moment(date.after).locale(locale).toDate(),
  }
}
function formatDayOfWeek(date: TDataPickerMecherRawModifierDayOfWeek) {
  return date
}

function formatDateWithSubtext(
  locale: TEDataPickerLocale,
  date: TDataPickerMecherRawModifierDateWithSubtext,
) {
  return moment(date.date).locale(locale).toDate()
}

function formatDateWithSubtextArray(
  locale: TEDataPickerLocale,
  dates: TDataPickerMecherRawModifierDateWithSubtextArray,
) {
  return dates.map((date) => moment(date.date).locale(locale).toDate())
}

export function modifiersFormatter(
  modifierDataValue: TDataPickerMecherRawModifier,
  locale: TEDataPickerLocale,
) {
  const modifierValue = dataType(modifierDataValue)
  switch (modifierValue.type) {
    case 'simple':
      return formatDate(locale, modifierValue.data)
    case 'array':
      return formatDateArray(locale, modifierValue.data)
    case 'range':
      return formatDateRange(locale, modifierValue.data)
    case 'before':
      return formatDateBefore(locale, modifierValue.data)
    case 'after':
      return formatDateAfter(locale, modifierValue.data)
    case 'interval':
      return formatDateInterval(locale, modifierValue.data)
    case 'withSubtext':
      return formatDateWithSubtext(locale, modifierValue.data)
    case 'withSubtextArray':
      return formatDateWithSubtextArray(locale, modifierValue.data)
    case 'dayOfWeek':
      return formatDayOfWeek(modifierValue.data)
  }
}
