import * as dataPicker from './dataPicker'
import * as string from './text'

export const formatter = {
  string,
  dataPicker,
}
