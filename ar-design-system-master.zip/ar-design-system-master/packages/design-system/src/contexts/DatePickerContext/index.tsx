import type { TDatePickerContextProps } from '@/contexts/datePickerContext'
import type { IComponentChildren } from '@/globals'

import { TDataPickerPublicModifier } from '@/components/form/dataPicker'

import { createContext, useContext } from 'react'

import { useDatePicker } from '~/stores/useDatePicker'

import { findWithSubtextByDay } from './functions'

const DatePickerContext = createContext({} as TDatePickerContextProps)

function DatePickerContextProvide({
  children,
  ...rest
}: Omit<TDatePickerContextProps, 'getSubtext'> & IComponentChildren) {
  const register = useDatePicker.getState().actions.register

  register(rest.name, rest.mode)

  const getSubtext = (
    day: Date,
    modifier: TDataPickerPublicModifier,
    variation?: string,
  ) => {
    return findWithSubtextByDay(rest, day, modifier, variation)
  }

  const datePickerContextValeu = {
    ...rest,
    getSubtext,
  }

  return (
    <DatePickerContext.Provider value={datePickerContextValeu}>
      {children}
    </DatePickerContext.Provider>
  )
}

function useDatePickerContext() {
  const context = useContext(DatePickerContext)
  if (!context) {
    throw new Error(
      'DatePickerContext: useContext must be used within a Componentrovider',
    )
  }
  return context
}

export { useDatePickerContext, DatePickerContextProvide }
