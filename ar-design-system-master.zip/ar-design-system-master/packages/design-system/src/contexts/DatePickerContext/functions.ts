import type {
  TDataPickerMecherRawModifierDateWithSubtext,
  TDataPickerPublicModifier,
} from '@/components/form/dataPicker'

import {
  ZDataPickerMecherRawModifierDateWithSubtext,
  ZDataPickerMecherRawModifierDateWithSubtextArray,
} from '@/components/form/dataPicker'
import { TDatePickerContextProps } from '@/contexts/datePickerContext'

import _ from 'lodash'
import moment from 'moment/min/moment-with-locales'

export function findWithSubtextByDay(
  props: Omit<TDatePickerContextProps, 'getSubtext'>,
  day: Date,
  modifier: TDataPickerPublicModifier,
  variation?: string,
) {
  const rawModifier = _.pick(props.modifiers, modifier)

  const withSubtextMecher =
    ZDataPickerMecherRawModifierDateWithSubtext.safeParse(rawModifier[modifier])
  const withSubtextArrayMecher =
    ZDataPickerMecherRawModifierDateWithSubtextArray.safeParse(
      rawModifier[modifier],
    )

  const findDayPricre = (
    data: TDataPickerMecherRawModifierDateWithSubtext,
    day: Date,
  ) => {
    if (moment(day).locale(props.locale).isSame(data.date, 'day')) {
      if (_.isString(data.value)) return data.value
      if (variation) return data.value[variation]
    }
  }

  if (withSubtextMecher.success) {
    return findDayPricre(withSubtextMecher.data, day)
  }

  if (withSubtextArrayMecher.success) {
    return _.chain(
      withSubtextArrayMecher.data.map((withSubtext) =>
        findDayPricre(withSubtext, day),
      ),
    )
      .compact()
      .head()
      .value()
  }
}
