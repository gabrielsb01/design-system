import type {
  TComponentContextProps,
  TComponentProviderProps,
} from '@/contexts/componentContext'

import { createContext, useContext as useComponentContext } from 'react'

const ComponentContext = createContext({} as TComponentContextProps)

function ComponentElementProvide({
  children,
  ...rest
}: TComponentProviderProps) {
  return (
    <ComponentContext.Provider value={rest}>
      {children}
    </ComponentContext.Provider>
  )
}

function useComponentElement() {
  const context = useComponentContext(ComponentContext)
  if (!context) {
    throw new Error(
      'ComponentElement: useContext must be used within a Componentrovider',
    )
  }
  return context
}

export { useComponentElement, ComponentElementProvide }
