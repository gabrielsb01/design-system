import type { TTagName } from '~/@types/globals'

export type TQASuffix = 'Input' | 'Output' | 'List' | 'ListItem' | 'Action'

export type TQATagIdSuffix = {
  [key in TTagName]: TQASuffix
}
