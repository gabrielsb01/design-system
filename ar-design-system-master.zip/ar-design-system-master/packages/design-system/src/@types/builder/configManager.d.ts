import type { ConfigType } from '@stitches/react/types/config'

import { DEFAULT_STITCHES_CONFIG } from '~/constants/config'

export type TStyleConfig = typeof DEFAULT_STITCHES_CONFIG

export interface IConfig {
  theme: ConfigType.Theme
}
