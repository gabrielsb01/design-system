export interface IObservable {
  addObserver(observer: unknown): void
  notifyObservers(updated: unknown): void
  update(theme: unknown): void
}
