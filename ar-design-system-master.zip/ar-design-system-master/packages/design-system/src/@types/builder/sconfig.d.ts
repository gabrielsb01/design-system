import type { IObservable } from './observable'

import { DEFAULT_STITCHES_CONFIG } from '~/constants/config'

export type TStyleConfig = typeof DEFAULT_STITCHES_CONFIG

export type TConfig = {
  theme: TStyleConfig
}

export interface IConfigBuilder {
  config: TConfig
  customConfig: TConfig
  defaultConfig: TConfig

  theme: TStyleConfig
  customTheme: TStyleConfig
  defaultTheme: TStyleConfig
}

export interface IConfigBuilderClass extends IObservable, IConfigBuilder {}
