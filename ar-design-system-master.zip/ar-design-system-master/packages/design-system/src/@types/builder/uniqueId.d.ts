export type TList = string[]
export type TIdTypes = 'string' | 'number'

export interface IUniqueIdBuilder {
  newId: (preffix?: string) => string
}

export interface IUniqueIdProps {
  type?: TIdTypes
}
