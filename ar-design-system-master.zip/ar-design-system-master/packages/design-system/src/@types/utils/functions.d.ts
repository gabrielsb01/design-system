export type TRef<T> =
  | ((instance: T | null) => void)
  | React.MutableRefObject<T | null>
  | null
