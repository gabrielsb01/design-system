import { ReactNode } from 'react'

export interface IComponentChildren {
  children: ReactNode
}

export type TTagName =
  | 'input'
  | 'select'
  | 'textarea'
  | 'p'
  | 'em'
  | 'h1'
  | 'h2'
  | 'h3'
  | 'h4'
  | 'h5'
  | 'h6'
  | 'img'
  | 'span'
  | 'strong'
  | 'ul'
  | 'ol'
  | 'tr'
  | 'th'
  | 'div'
  | 'table'
  | 'li'
  | 'td'
  | 'a'
  | 'button'
