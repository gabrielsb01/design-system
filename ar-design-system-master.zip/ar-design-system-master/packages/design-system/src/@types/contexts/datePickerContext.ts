import {
  ZDataPickerMecherRawModifierDate,
  ZDataPickerMecherRawModifierDateArray,
  ZDataPickerMecherRawModifierDateRange,
  ZDataPickerMecherRawModifierMonth,
  ZDataPickerMecherRawModifierYear,
  ZDataPickerRawModifier,
  ZEDataPickerLocale,
  ZEDataPickerMode,
  ZEDataPickerPublicModifier,
  ZEDataPickerWeekDisplay,
  ZEDataPickerWeekNumber,
} from '@/components/form/dataPicker'

import { z } from 'zod'

export const ZDatePickerBaseContextProps = z.object({
  name: z.string(),
  locale: ZEDataPickerLocale,
  modifiers: ZDataPickerRawModifier,

  // --------
  subtextVariations: z.record(z.string()).optional(),
  // --------

  fromDate: ZDataPickerMecherRawModifierDate.optional(),
  toDate: ZDataPickerMecherRawModifierDate.optional(),
  fromMonth: ZDataPickerMecherRawModifierMonth.optional(),
  toMonth: ZDataPickerMecherRawModifierMonth.optional(),
  fromYear: ZDataPickerMecherRawModifierYear.optional(),
  toYear: ZDataPickerMecherRawModifierYear.optional(),
  // --------

  outsideDays: z.boolean(),
  selectableOutsideDays: z.boolean(),
  // --------

  month: ZDataPickerMecherRawModifierMonth.optional(),
  today: ZDataPickerMecherRawModifierDate.optional(),
  defaultMonth: ZDataPickerMecherRawModifierMonth.optional(),
  numberOfMonths: z.number(),
  // --------

  weekStartsOn: ZEDataPickerWeekNumber,
  weekDisplay: ZEDataPickerWeekDisplay,

  getSubtext: z
    .function(z.tuple([]))
    .args(z.date(), ZEDataPickerPublicModifier, z.string().optional())
    .returns(z.string().optional()),
})

export const ZDatePickerDefaultContextProps =
  ZDatePickerBaseContextProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.default).optional(),
  })

export const ZDatePickerRangeContextProps = ZDatePickerBaseContextProps.extend({
  mode: z.literal(ZEDataPickerMode.enum.range),
  selected: ZDataPickerMecherRawModifierDateRange.optional(),
  min: z.number().optional(),
  max: z.number().optional(),
})

export const ZDatePickerMultipleContextProps =
  ZDatePickerBaseContextProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.multiple),
    selected: ZDataPickerMecherRawModifierDateArray.optional(),
    min: z.number().optional(),
    max: z.number().optional(),
  })

export const ZDatePickerSingleContextProps = ZDatePickerBaseContextProps.extend(
  {
    mode: z.literal(ZEDataPickerMode.enum.single),
    selected: ZDataPickerMecherRawModifierDate.optional(),
    required: z.boolean().optional(),
  },
)

export const ZDatePickerContextProps = z.union([
  ZDatePickerDefaultContextProps,
  ZDatePickerRangeContextProps,
  ZDatePickerMultipleContextProps,
  ZDatePickerSingleContextProps,
])

export type TDatePickerContextProps = z.infer<typeof ZDatePickerContextProps>
