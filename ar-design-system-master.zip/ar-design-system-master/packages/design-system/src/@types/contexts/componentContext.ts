import type { ReactNode } from 'react'

import { z } from 'zod'

export const ZComponentProviderProps = z.object({
  name: z.string(),
})
export const ZComponentContextProps = z.object({
  name: z.string(),
})

export type TComponentProviderProps = z.infer<
  typeof ZComponentProviderProps
> & {
  children: ReactNode
}
export type TComponentContextProps = z.infer<typeof ZComponentContextProps>
