import type { LucideIcon } from 'lucide-react'

import { icons as lucide } from 'lucide-react'

export type TIconLib = 'lucide'

export interface IIconLibBaseProps {
  title?: string
  description?: string
}

export interface IIconLibLucideProps extends IIconLibBaseProps {
  icons: typeof lucide
  icon?: LucideIcon
}
