import { z } from 'zod'

import {
  ZEDataPickerClassNames,
  ZEDataPickerMode,
  ZEDataPickerWeekDisplay,
  ZEDataPickerWeekNumber,
} from './dataPickerEnums'
import {
  ZDataPickerCustomModifier,
  ZDataPickerMecherModifier,
  ZDataPickerMecherModifierDate,
  ZDataPickerMecherModifierDateArray,
  ZDataPickerMecherModifierDateRange,
} from './dataPickerModifiers'

export const ZDataPickerBaseDayPickerProps = z.object({
  today: z.date().optional(),
  month: z.date().optional(),
  // --------
  fromDate: z.date().optional(),
  toDate: z.date().optional(),
  fromMonth: z.date().optional(),
  toMonth: z.date().optional(),
  fromYear: z.number().positive().optional(),
  toYear: z.number().positive().optional(),
  // --------
  showOutsideDays: z.boolean().optional(),
  // --------
  defaultMonth: z.date().optional(),
  numberOfMonths: z.number().positive().optional(),
  // --------
  weekStartsOn: ZEDataPickerWeekNumber.optional(),
  weekDisplay: ZEDataPickerWeekDisplay.optional(),
  // ----

  hidden: ZDataPickerMecherModifier.optional(),
  disabled: ZDataPickerMecherModifier.optional(),
  selected: ZDataPickerMecherModifier.optional(),
  modifiers: ZDataPickerCustomModifier.optional(),

  classNames: z.record(ZEDataPickerClassNames, z.string()),

  // disableNavigation?: boolean;
  // pagedNavigation?: boolean;

  // -------
  // disableNavigation?: boolean;
  // pagedNavigation?: boolean;
  // reverseMonths?: boolean;
  // fixedWeeks?: boolean;
  // showWeekNumber?: boolean;
  // firstWeekContainsDate?: 1 | 4;
  // ISOWeek?: boolean;
  // --------
  // onMonthChange?: MonthChangeEventHandler;
  // onNextClick?: MonthChangeEventHandler;
  // onPrevClick?: MonthChangeEventHandler;
  // onWeekNumberClick?: WeekNumberClickEventHandler;
  // onDayClick?: DayClickEventHandler;
  // onDayFocus?: DayFocusEventHandler;
  // onDayBlur?: DayFocusEventHandler;
  // onDayMouseEnter?: DayMouseEventHandler;
  // onDayMouseLeave?: DayMouseEventHandler;
  // onDayKeyDown?: DayKeyboardEventHandler;
  // onDayKeyUp?: DayKeyboardEventHandler;
  // onDayKeyPress?: DayKeyboardEventHandler;
  // onDayPointerEnter?: DayPointerEventHandler;
  // onDayPointerLeave?: DayPointerEventHandler;
  // onDayTouchCancel?: DayTouchEventHandler;
  // onDayTouchEnd?: DayTouchEventHandler;
  // onDayTouchMove?: DayTouchEventHandler;
  // onDayTouchStart?: DayTouchEventHandler;
  // onMonthChange?: MonthChangeEventHandler;
  //
})

export const ZDataPickerDefaultDayPickerProps =
  ZDataPickerBaseDayPickerProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.default).optional(),
  })

export const ZDataPickerRangeDayPickerProps =
  ZDataPickerBaseDayPickerProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.range),
    selected: ZDataPickerMecherModifierDateRange.optional(),
    min: z.number().optional(),
    max: z.number().optional(),
  })

export const ZDataPickerMultipleDayPickerProps =
  ZDataPickerBaseDayPickerProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.multiple),
    selected: ZDataPickerMecherModifierDateArray.optional(),
    min: z.number().optional(),
    max: z.number().optional(),
  })

export const ZDataPickerSingleDayPickerProps =
  ZDataPickerBaseDayPickerProps.extend({
    mode: z.literal(ZEDataPickerMode.enum.single),
    selected: ZDataPickerMecherModifierDate.optional(),
    required: z.boolean().optional(),
  })

export const ZDatePickerDayPickeProps = z.union([
  ZDataPickerDefaultDayPickerProps,
  ZDataPickerRangeDayPickerProps,
  ZDataPickerMultipleDayPickerProps,
  ZDataPickerSingleDayPickerProps,
])

//
//
//
//

export type TDataPickerBaseDayPickerProps = z.infer<
  typeof ZDataPickerBaseDayPickerProps
>
export type TDataPickerDefaultDayPickerProps = z.infer<
  typeof ZDataPickerDefaultDayPickerProps
>
export type TDataPickerRangeDayPickerProps = z.infer<
  typeof ZDataPickerRangeDayPickerProps
>
export type TDataPickerMultipleDayPickerProps = z.infer<
  typeof ZDataPickerMultipleDayPickerProps
>
export type TDataPickerSingleDayPickerProps = z.infer<
  typeof ZDataPickerSingleDayPickerProps
>
export type TDatePickerDayPickeProps = z.infer<typeof ZDatePickerDayPickeProps>
