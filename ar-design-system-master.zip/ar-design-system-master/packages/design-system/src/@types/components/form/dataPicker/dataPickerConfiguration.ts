import { z } from 'zod'

import { ZEDataPickerClassNames } from './dataPickerEnums'

export const ZDataPickerClasses = z.record(ZEDataPickerClassNames, z.string())

//
//
//
//

export type TDataPickerClasses = z.infer<typeof ZDataPickerClasses>
