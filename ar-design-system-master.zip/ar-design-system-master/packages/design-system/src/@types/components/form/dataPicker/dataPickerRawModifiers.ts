import { z } from 'zod'

import { ZEDataPickerWeekNumber } from './dataPickerEnums'

// ======= Mecher
export const ZDataPickerMecherRawModifierYear = z.number().positive().min(1900)
export const ZDataPickerMecherRawModifierMonth = z
  .string()
  .regex(/^\d{4}-\d{2}$/)

export const ZDataPickerMecherRawModifierDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)

export const ZDataPickerMecherRawModifierDateArray = z.array(
  ZDataPickerMecherRawModifierDate,
)

export const ZDataPickerMecherRawModifierDateRange = z.object({
  from: ZDataPickerMecherRawModifierDate,
  to: ZDataPickerMecherRawModifierDate,
})

export const ZDataPickerMecherRawModifierDateAfter = z.object({
  after: ZDataPickerMecherRawModifierDate,
})
export const ZDataPickerMecherRawModifierDateBefore = z.object({
  before: ZDataPickerMecherRawModifierDate,
})

export const ZDataPickerMecherRawModifierDateInterval = z.object({
  after: ZDataPickerMecherRawModifierDate,
  before: ZDataPickerMecherRawModifierDate,
})

export const ZDataPickerMecherRawModifierDayOfWeek = z.object({
  dayOfWeek: z.array(ZEDataPickerWeekNumber),
})

export const ZDataPickerMecherRawModifierDateWithSubtextValue = z.union([
  z.string(),
  z.record(z.string()),
])
export const ZDataPickerMecherRawModifierDateWithSubtext = z.object({
  value: ZDataPickerMecherRawModifierDateWithSubtextValue,
  date: ZDataPickerMecherRawModifierDate,
})

export const ZDataPickerMecherRawModifierDateWithSubtextArray = z.array(
  ZDataPickerMecherRawModifierDateWithSubtext,
)

// ======= Mecher Modifier
export const ZDataPickersSimpleMecherRawModifier = z.union([
  ZDataPickerMecherRawModifierDate,
  ZDataPickerMecherRawModifierDateArray,
  ZDataPickerMecherRawModifierDateRange,
  ZDataPickerMecherRawModifierDateAfter,
  ZDataPickerMecherRawModifierDateBefore,
  ZDataPickerMecherRawModifierDateInterval,
  ZDataPickerMecherRawModifierDayOfWeek,
])

export const ZDataPickerWithSubtextMecherRawModifier = z.union([
  ZDataPickerMecherRawModifierDateWithSubtext,
  ZDataPickerMecherRawModifierDateWithSubtextArray,
])

export const ZDataPickerMecherRawModifier = z.union([
  ZDataPickerWithSubtextMecherRawModifier,
  ZDataPickersSimpleMecherRawModifier,
])

// ======= Modifiers Types

export const ZDataPickerHiddenRawModifier = ZDataPickersSimpleMecherRawModifier
export const ZDataPickerDisabledRawModifier =
  ZDataPickersSimpleMecherRawModifier
export const ZDataPickerHighlightRawModifier =
  ZDataPickersSimpleMecherRawModifier
// ------------------------------------------------------------
export const ZDataPickerSubtextRawModifier =
  ZDataPickerWithSubtextMecherRawModifier

// ======= Modifiers

export const ZDataPickerRawModifier = z.object({
  hidden: ZDataPickerHiddenRawModifier.optional(),
  disabled: ZDataPickerDisabledRawModifier.optional(),
  subtext: ZDataPickerSubtextRawModifier.optional(),
  highlight: ZDataPickerHighlightRawModifier.optional(),
})

//
//
//
//

export type TDataPickerMecherRawModifierYear = z.infer<
  typeof ZDataPickerMecherRawModifierYear
>
export type TDataPickerMecherRawModifierMonth = z.infer<
  typeof ZDataPickerMecherRawModifierMonth
>
export type TDataPickerMecherRawModifierDate = z.infer<
  typeof ZDataPickerMecherRawModifierDate
>
export type TDataPickerMecherRawModifierDateArray = z.infer<
  typeof ZDataPickerMecherRawModifierDateArray
>
export type TDataPickerMecherRawModifierDateRange = z.infer<
  typeof ZDataPickerMecherRawModifierDateRange
>
export type TDataPickerMecherRawModifierDateAfter = z.infer<
  typeof ZDataPickerMecherRawModifierDateAfter
>
export type TDataPickerMecherRawModifierDateBefore = z.infer<
  typeof ZDataPickerMecherRawModifierDateBefore
>
export type TDataPickerMecherRawModifierDateInterval = z.infer<
  typeof ZDataPickerMecherRawModifierDateInterval
>
export type TDataPickerMecherRawModifierDayOfWeek = z.infer<
  typeof ZDataPickerMecherRawModifierDayOfWeek
>
export type TDataPickerMecherRawModifierDateWithSubtext = z.infer<
  typeof ZDataPickerMecherRawModifierDateWithSubtext
>
export type TDataPickerMecherRawModifierDateWithSubtextArray = z.infer<
  typeof ZDataPickerMecherRawModifierDateWithSubtextArray
>
export type TDataPickersSimpleMecherRawModifier = z.infer<
  typeof ZDataPickersSimpleMecherRawModifier
>
export type TDataPickerWithSubtextMecherRawModifier = z.infer<
  typeof ZDataPickerWithSubtextMecherRawModifier
>
export type TDataPickerMecherRawModifier = z.infer<
  typeof ZDataPickerMecherRawModifier
>
export type TDataPickerHiddenRawModifier = z.infer<
  typeof ZDataPickerHiddenRawModifier
>
export type TDataPickerDisabledRawModifier = z.infer<
  typeof ZDataPickerDisabledRawModifier
>
export type TDataPickerHighlightRawModifier = z.infer<
  typeof ZDataPickerHighlightRawModifier
>
export type TDataPickerSubtextRawModifier = z.infer<
  typeof ZDataPickerSubtextRawModifier
>
export type TDataPickerRawModifier = z.infer<typeof ZDataPickerRawModifier>
