import type { LucideProps } from 'lucide-react'

import { icons } from 'lucide-react'

export type TLucideIconPosition = 'start' | 'end'

export type TLucideIcon = keyof typeof icons

export interface ILucideIconProps extends Omit<LucideProps, 'ref'> {
  name: TLucideIcon
  position: TLucideIconPosition
}

export interface ITextFieldStoreField {
  focused: boolean
  empty: boolean
  icon?: ILucideIconProps
}

export type TTextFieldStoreData = Record<string, ITextFieldStoreField>

export interface ITextFieldStoreActions {
  register(name: string, iconProps?: ILucideIconProps): void
  update(name: string, iconProps?: ILucideIconProps): void
  setFocusedStatus(name: string, status?: boolean): void
  setEmptyStatus(name: string, status?: boolean): void
}

export interface ITextFieldStore {
  data: TTextFieldStoreData
  actions: ITextFieldStoreActions
}
