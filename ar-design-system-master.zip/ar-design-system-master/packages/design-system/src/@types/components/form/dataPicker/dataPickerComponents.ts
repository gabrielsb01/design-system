import { z } from 'zod'

import {
  ZEDataPickerLocale,
  ZEDataPickerMode,
  ZEDataPickerWeekDisplay,
  ZEDataPickerWeekNumber,
} from './dataPickerEnums'
import { ZDataPickerActiveModifiers } from './dataPickerModifiers'
import {
  ZDataPickerDisabledRawModifier,
  ZDataPickerHiddenRawModifier,
  ZDataPickerHighlightRawModifier,
  ZDataPickerMecherRawModifierDate,
  ZDataPickerMecherRawModifierDateArray,
  ZDataPickerMecherRawModifierDateRange,
  ZDataPickerMecherRawModifierMonth,
  ZDataPickerMecherRawModifierYear,
  ZDataPickerSubtextRawModifier,
} from './dataPickerRawModifiers'

export const ZDatePickerDayDecorationSelectedProps = z.object({
  highlight: z.boolean().optional(),
  rangeStart: z.boolean().optional(),
  rangeEnd: z.boolean().optional(),
})
export const ZDataPickerHeaderWeekDayProps = z.object({
  weekday: ZEDataPickerWeekNumber,
})

export const ZDatePickerDayProps = z.object({
  date: z.date(),
  displayMonth: z.date(),
})

export const ZDatePickerDayContentProps = ZDatePickerDayProps.extend({
  onDayClick: z
    .function(z.tuple([z.date(), ZDataPickerActiveModifiers, z.any()]))
    .returns(z.void())
    .optional(),
})

export const ZDatePickerBaseRootProps = z.object({
  name: z.string(),

  locale: ZEDataPickerLocale.optional(),
  subtextVariations: z.record(z.string()).optional(),

  // --------
  fromDate: ZDataPickerMecherRawModifierDate.optional(),
  toDate: ZDataPickerMecherRawModifierDate.optional(),
  fromMonth: ZDataPickerMecherRawModifierMonth.optional(),
  toMonth: ZDataPickerMecherRawModifierMonth.optional(),
  fromYear: ZDataPickerMecherRawModifierYear.optional(),
  toYear: ZDataPickerMecherRawModifierYear.optional(),
  // --------
  outsideDays: z.boolean().optional(),
  selectableOutsideDays: z.boolean().optional(),
  // --------
  month: ZDataPickerMecherRawModifierMonth.optional(),
  today: ZDataPickerMecherRawModifierDate.optional(),
  defaultMonth: ZDataPickerMecherRawModifierMonth.optional(),
  numberOfMonths: z.number().positive().optional(),
  // --------
  weekStartsOn: ZEDataPickerWeekNumber.optional(),
  weekDisplay: ZEDataPickerWeekDisplay.optional(),
  // ----

  hidden: ZDataPickerHiddenRawModifier.optional(),
  disabled: ZDataPickerDisabledRawModifier.optional(),
  subtext: ZDataPickerSubtextRawModifier.optional(),
  highlight: ZDataPickerHighlightRawModifier.optional(),
})

export const ZDatePickerRootBaseModifiersProps =
  ZDatePickerBaseRootProps.extend({})

export const ZDatePickerDefaultRootProps = ZDatePickerBaseRootProps.extend({
  mode: z.literal(ZEDataPickerMode.enum.default).optional(),
})

export const ZDatePickerRangeRootProps = ZDatePickerBaseRootProps.extend({
  mode: z.literal(ZEDataPickerMode.enum.range),
  selected: ZDataPickerMecherRawModifierDateRange.optional(),
  min: z.number().optional(),
  max: z.number().optional(),
})

export const ZDatePickerMultipleRootProps = ZDatePickerBaseRootProps.extend({
  mode: z.literal(ZEDataPickerMode.enum.multiple),
  selected: ZDataPickerMecherRawModifierDateArray.optional(),
  min: z.number().optional(),
  max: z.number().optional(),
})

export const ZDatePickerSingleRootProps = ZDatePickerBaseRootProps.extend({
  mode: z.literal(ZEDataPickerMode.enum.single),
  selected: ZDataPickerMecherRawModifierDate.optional(),
  required: z.boolean().optional(),
})

export const ZDatePickerRootProps = z.union([
  ZDatePickerDefaultRootProps,
  ZDatePickerRangeRootProps,
  ZDatePickerMultipleRootProps,
  ZDatePickerSingleRootProps,
])
//
//
//
//

export type TDatePickerDayDecorationSelectedProps = z.infer<
  typeof ZDatePickerDayDecorationSelectedProps
>
export type TDataPickerHeaderWeekDayProps = z.infer<
  typeof ZDataPickerHeaderWeekDayProps
>
export type TDatePickerDayProps = z.infer<typeof ZDatePickerDayProps>
export type TDatePickerDayContentProps = z.infer<
  typeof ZDatePickerDayContentProps
>
export type TDatePickerRootProps = z.infer<typeof ZDatePickerRootProps>
