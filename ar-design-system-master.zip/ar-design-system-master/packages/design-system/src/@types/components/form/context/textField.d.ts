import type { ReactNode } from 'react'

export interface ITextFieldContextProps {
  name: string
}

interface ITextFieldProviderProps {
  children: ReactNode
  name: string
}
