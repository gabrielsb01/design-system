import { z } from 'zod'

import {
  ZEDataPickerActiveModifier,
  ZEDataPickerPublicModifier,
  ZEDataPickerWeekNumber,
} from './dataPickerEnums'

// ======= Mecher
export const ZDataPickerMecherModifierDate = z.date()

export const ZDataPickerMecherModifierDateArray = z.array(
  ZDataPickerMecherModifierDate,
)
export const ZDataPickerMecherModifierDateRange = z.object({
  from: ZDataPickerMecherModifierDate,
  to: ZDataPickerMecherModifierDate.optional(),
})

export const ZDataPickerMecherModifierDateAfter = z.object({
  after: ZDataPickerMecherModifierDate,
})
export const ZDataPickerMecherModifierDateBefore = z.object({
  before: ZDataPickerMecherModifierDate,
})

export const ZDataPickerMecherModifierDateInterval = z.object({
  after: ZDataPickerMecherModifierDate,
  before: ZDataPickerMecherModifierDate,
})

export const ZDataPickerMecherModifierDayOfWeek = z.object({
  dayOfWeek: z.array(ZEDataPickerWeekNumber),
})

// ======= Mecher Modifier
export const ZDataPickerMecherModifier = z.union([
  ZDataPickerMecherModifierDate,
  ZDataPickerMecherModifierDateArray,
  ZDataPickerMecherModifierDateRange,
  ZDataPickerMecherModifierDateAfter,
  ZDataPickerMecherModifierDateBefore,
  ZDataPickerMecherModifierDateInterval,
  ZDataPickerMecherModifierDayOfWeek,
])

export const ZDataPickerModifier = z.record(
  ZEDataPickerPublicModifier,
  ZDataPickerMecherModifier,
)

export const ZDataPickerActiveModifiers = z.record(
  ZEDataPickerActiveModifier,
  z.literal(true),
)
export const ZDataPickerCustomModifier = z.record(ZDataPickerMecherModifier)

//
//
//
//

export type TDataPickerMecherModifierDate = z.infer<
  typeof ZDataPickerMecherModifierDate
>
export type TDataPickerMecherModifierDateArray = z.infer<
  typeof ZDataPickerMecherModifierDateArray
>
export type TDataPickerMecherModifierDateRange = z.infer<
  typeof ZDataPickerMecherModifierDateRange
>
export type TDataPickerMecherModifierDateAfter = z.infer<
  typeof ZDataPickerMecherModifierDateAfter
>
export type TDataPickerMecherModifierDateBefore = z.infer<
  typeof ZDataPickerMecherModifierDateBefore
>
export type TDataPickerMecherModifierDateInterval = z.infer<
  typeof ZDataPickerMecherModifierDateInterval
>
export type TDataPickerMecherModifierDayOfWeek = z.infer<
  typeof ZDataPickerMecherModifierDayOfWeek
>
export type TDataPickerMecherModifier = z.infer<
  typeof ZDataPickerMecherModifier
>
export type TDataPickerActiveModifiers = z.infer<
  typeof ZDataPickerActiveModifiers
>
export type TDataPickerModifier = z.infer<typeof ZDataPickerModifier>
