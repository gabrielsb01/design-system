import {
  CLASS_NAMES,
  CUSTOM_MODIFIER,
  INTERNAL_MODIFIER,
  LOCALE,
  MODE,
  PUBLIC_MODIFIER,
  WEEK_DISPLAY,
  WEEK_DISPLAY_TYPE,
  WEEK_NUMBER,
  WITH_VALUE_MODIFIER,
} from '_CST/datePicker'
import { z } from 'zod'

export const ZEDataPickerMode = z.enum(MODE)
export const ZEDataPickerLocale = z.enum(LOCALE)

export const ZEDataPickerPublicModifier = z.enum(PUBLIC_MODIFIER)
export const ZEDataPickerCustomModifier = z.enum(CUSTOM_MODIFIER)
export const ZEDataPickerInternalModifier = z.enum(INTERNAL_MODIFIER)
export const ZEDataPickerPublicWithValueModifier = z.enum(WITH_VALUE_MODIFIER)
export const ZEDataPickerClassNames = z.enum(CLASS_NAMES)

export const ZEDataPickerActiveModifier = z.enum([
  ...ZEDataPickerPublicModifier.options,
  ...ZEDataPickerInternalModifier.options,
])

export const ZEDataPickerWeekDisplay = z.enum(WEEK_DISPLAY)
export const ZEDataPickerWeekNumber = z.nativeEnum(WEEK_NUMBER)
export const ZEDataPickerWeekDisplayType = z.nativeEnum(WEEK_DISPLAY_TYPE)

//
//
//
//

export type TEDataPickerMode = z.infer<typeof ZEDataPickerMode>
export type TEDataPickerLocale = z.infer<typeof ZEDataPickerLocale>
export type TDataPickerPublicModifier = z.infer<
  typeof ZEDataPickerPublicModifier
>
export type TDataPickerInternalModifier = z.infer<
  typeof ZEDataPickerInternalModifier
>
export type TDataPickerCustomModifier = z.infer<
  typeof ZEDataPickerCustomModifier
>
export type TEDataPickerPublicWithValueModifier = z.infer<
  typeof ZEDataPickerPublicWithValueModifier
>
export type TEDataPickerClassNames = z.infer<typeof ZEDataPickerClassNames>
export type TDataPickerActiveModifier = z.infer<
  typeof ZEDataPickerActiveModifier
>
export type TDataPickerWeekDisplay = z.infer<typeof ZEDataPickerWeekDisplay>
export type TDataPickerWeekNumber = z.infer<typeof ZEDataPickerWeekNumber>
export type TDataPickerWeekDisplayType = z.infer<
  typeof ZEDataPickerWeekDisplayType
>
