import type { ConfigType } from '@stitches/react/types/config'
import type { IConfig, TStyleConfig } from '~/@types/builder/configManager'

export abstract class AConfigManagerBuilder {
  static theme: ConfigType.Theme<TStyleConfig>
  static setConfig: (customConfig: Partial<IConfig>) => void
}
