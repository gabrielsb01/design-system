import {
  ZDataPickerMecherModifierDate,
  ZDataPickerMecherModifierDateArray,
  ZDataPickerMecherModifierDateRange,
  ZEDataPickerMode,
} from '@/components/form/dataPicker'

import { z } from 'zod'

export const ZStoreDatePickerDataProps = z.object({
  mode: ZEDataPickerMode,
  subtextVariation: z.string().optional(),
  selected: z
    .union([
      ZDataPickerMecherModifierDate,
      ZDataPickerMecherModifierDateRange.partial(),
      ZDataPickerMecherModifierDateArray,
    ])
    .optional(),
})

export const ZStoreDatePickerSelected = z.union([
  ZDataPickerMecherModifierDate,
  ZDataPickerMecherModifierDateArray,
  ZDataPickerMecherModifierDateRange.partial(),
])

export const ZStoreDatePickerData = z.object({
  datePicker: z.record(ZStoreDatePickerDataProps),
})

export const ZStoreDatePickerActions = z.object({
  register: z
    .function(z.tuple([z.string(), ZEDataPickerMode.optional()]))
    .returns(z.void()),
  setSelected: z
    .function(z.tuple([z.string(), ZStoreDatePickerSelected.optional()]))
    .returns(z.void()),
  setSubtextVariation: z
    .function(z.tuple([z.string(), z.string().optional()]))
    .returns(z.void()),
})

export const ZStoreDatePicker = z.object({
  data: ZStoreDatePickerData,
  actions: ZStoreDatePickerActions,
})

//
//
//
//

export type TStoreDatePickerDataProps = z.infer<
  typeof ZStoreDatePickerDataProps
>
export type TStoreDatePickerData = z.infer<typeof ZStoreDatePickerData>
export type TStoreDatePickerActions = z.infer<typeof ZStoreDatePickerActions>
export type TStoreDatePicker = z.infer<typeof ZStoreDatePicker>
