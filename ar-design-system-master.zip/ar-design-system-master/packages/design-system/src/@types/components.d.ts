export type TCss = {
  [K in keyof C]: K extends keyof CSS ? CSS[K] : never
}
