import { TQATagIdSuffix } from '~/@types/qa'

export const TAG_TEST_ID_SUFFIX = {
  input: 'Input',
  select: 'Input',
  textarea: 'Input',

  p: 'Output',
  em: 'Output',
  h1: 'Output',
  h2: 'Output',
  h3: 'Output',
  h4: 'Output',
  h5: 'Output',
  h6: 'Output',
  img: 'Output',
  span: 'Output',
  strong: 'Output',

  ul: 'List',
  ol: 'List',
  tr: 'List',
  th: 'List',
  div: 'List',
  table: 'List',

  li: 'ListItem',
  td: 'ListItem',

  a: 'Action',
  button: 'Action',
} satisfies TQATagIdSuffix

export const TAG_SEQUENTIAL = ['li', 'td']
