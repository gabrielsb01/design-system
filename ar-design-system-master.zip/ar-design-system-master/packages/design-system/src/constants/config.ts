import {
  borderStyles,
  borderWidths,
  colors,
  fontSizes,
  fontWeights,
  letterSpacings,
  radii,
  shadows,
  space,
} from '@gogipsy/ds-tokens'

export const CONFIG_FILE_BASE_NAME = '.[PROJECT_NAME]rc'

export const DEFAULT_STITCHES_CONFIG = {
  colors,
  space,
  radii,
  borderStyles,
  borderWidths,
  shadows,
  fontSizes,
  fontWeights,
  letterSpacings,
}

export const DEFAULT_CONFIG = {
  theme: DEFAULT_STITCHES_CONFIG,
}
