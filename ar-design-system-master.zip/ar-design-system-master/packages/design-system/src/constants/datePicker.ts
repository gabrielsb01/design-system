import { TDataPickerClasses } from '@/components/form/dataPicker/dataPickerConfiguration'

export const LOCALE = ['pt-br'] as const

export const WEEK_DISPLAY = [
  'number',
  'ordinal',
  'abbreviation',
  'full',
] as const

export const WEEK_DISPLAY_TYPE = {
  full: 'dddd',
  number: 'd',
  ordinal: 'dd',
  abbreviation: 'ddd',
} as const

export const MODE = ['multiple', 'range', 'single', 'default'] as const

export const INTERNAL_MODIFIER = [
  'today',
  'outside',
  'selected',
  'range_start',
  'range_end',
  'range_middle',
  'start_week',
  'end_week',
] as const

export const PUBLIC_MODIFIER = [
  'hidden',
  'disabled',
  'subtext',
  'highlight',
] as const

export const CUSTOM_MODIFIER = ['subtext', 'highlight'] as const

export const WITH_VALUE_MODIFIER = ['subtext'] as const

export const WEEK_NUMBER = {
  sunday: 0,
  monday: 1,
  tuesday: 2,
  wednesday: 3,
  thursday: 4,
  friday: 5,
  saturday: 6,
} as const

export const CLASS_NAMES = [
  'month',
  'button',
  'button_reset',
  'caption',
  'caption_between',
  'caption_dropdowns',
  'caption_end',
  'caption_label',
  'caption_start',
  'cell',
  'day',
  'day_disabled',
  'day_hidden',
  'day_outside',
  'day_range_end',
  'day_range_middle',
  'day_range_start',
  'day_selected',
  'day_today',
  'dropdown',
  'dropdown_icon',
  'dropdown_month',
  'dropdown_year',
  'head',
  'head_cell',
  'head_row',
  'months',
  'multiple_months',
  'nav',
  'nav_button',
  'nav_button_next',
  'nav_button_previous',
  'nav_icon',
  'root',
  'row',
  'table',
  'tbody',
  'tfoot',
  'vhidden',
  'weeknumber',
  'with_weeknumber',
] as const

export const DEFAULT_CLASS = {
  month: 'month',
} satisfies TDataPickerClasses
