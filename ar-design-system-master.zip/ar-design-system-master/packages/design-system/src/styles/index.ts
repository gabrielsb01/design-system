import { createStitches, defaultThemeMap } from '@stitches/react'

import { globalConfig } from '~/services'

export const {
  css,
  theme,
  styled,
  config,
  globalCss,
  keyframes,
  getCssText,
  createTheme,
} = createStitches({
  themeMap: {
    ...defaultThemeMap,
    width: 'space',
    height: 'space',
    minWidth: 'space',
    minHeight: 'space',
    outlineWidth: 'borderWidths',
    outlineStyle: 'borderStyles',
  },
  theme: globalConfig.theme,
})
