import { ConfigManager } from '~/utils/builder'

export const globalConfig = ConfigManager()
